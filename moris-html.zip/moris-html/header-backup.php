<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta name="description" content="PR | Digital | Social Media Marketing Agency - High Performance Targeting">
      <meta name="keywords" content="Moris PR">
      <meta name="author" content="Moris PR">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>PR | Digital | Social Media Marketing Agency - High Performance Targeting</title>
      <link rel="icon" href="images/moris-favicon.png" type="image/gif" sizes="16x16">
      <link href="css/custom.css" rel="stylesheet">
      <link href="css/aos.css" rel="stylesheet">
      <script src="js/custom.js"></script>
      <script src="js/aos.js"></script>
      <script src="https://kit.fontawesome.com/8612db66ee.js"></script>
      <link href="css/bootstrap.min.css" rel="stylesheet">
     
      <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
      <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
      <![endif]-->

   </head>
   <body>
      <header class="moris-header">
        <!-- top navigation start -->
        <div class="top-navigation">
           <div class="container-fluid">
              <div class="row align-items">
                 <div class="col-lg-4 hide-for-mobile">
                    <ul class="moris-celebrity">
                       <li>
                          <a href="https://www.morisgigs.in/directories">Celebrity Directory</a>
                          <span>...</span>
                          <a href="https://www.morisgigs.in/SignUp">Enroll as Celeb </a>
                       </li>
                    </ul>
                 </div>
                 <div class="col-lg-8">
                    <div class="to-user-btn text-right">
                       <ul>
                          <li>
                             <a href="#"><i class="fab fa-facebook-f"></i></a>
                          </li>
                          <li>
                             <a href="#"><i class="fab fa-twitter"></i></a>
                          </li>
                          <li>
                             <a href="#"><i class="fab fa-linkedin-in"></i></a>
                          </li>
                          <li>
                             <a href="#"><i class="fab fa-pinterest-p"></i></a>
                          </li>
                          <li>
                             <a href="#"><i class="far fa-user"></i></a>
                          </li>
                          <li>
                             <a href="https://www.morisgigs.in/UserSignin">Sign in</a>
                             <span>...</span>
                             <a href="https://www.morisgigs.in/UserSignin">Register</a>
                          </li>
                          <li class="hide-for-mobile">
                             <a target="_blank" href="https://www.morisgigs.in/login" class="manager-login">Manager Login</a>
                          </li>
                       </ul>
                    </div>
                 </div>
              </div>
           </div>
        </div>
        <!-- top navigation end -->
        <div class="main-header header" id="moris-header">
           <div class="container-fluid">
              <div class="row">
                 <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                  <nav class="navbar navbar-expand-lg navbar-light">
                     <div class="container-fluid">
                        <a class="navbar-brand" href="http://morispr.in/">
                           <img src="images/moris-logo.png" alt="moris-logo">
                        </a>
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                           <span class="navbar-toggler-icon"></span>
                        </button>
                        <!-- hide for desktop -->
                        <!-- <button class="mobileview-btn hide" onclick="openMobile()"><span class="navbar-toggler-icon"></span></button> -->
                        <!-- hide for desktop end -->
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                           <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                              <li class="nav-item">
                                 <a class="nav-link" href="#">MORIS PR
                                    <svg xmlns="" xmlns:xlink="" version="1.1" id="Layer_1" x="0px" y="0px" viewBox="0 0 330 330" style="enable-background:new 0 0 330 330;" xml:space="preserve">
                                       <path id="XMLID_225_" d="M325.607,79.393c-5.857-5.857-15.355-5.858-21.213,0.001l-139.39,139.393L25.607,79.393  c-5.857-5.857-15.355-5.858-21.213,0.001c-5.858,5.858-5.858,15.355,0,21.213l150.004,150c2.813,2.813,6.628,4.393,10.606,4.393  s7.794-1.581,10.606-4.394l149.996-150C331.465,94.749,331.465,85.251,325.607,79.393z"></path>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                    </svg>
                                 </a>
                                 <!-- moris mega menu start -->
                                 <div class="moris-mega-menu">
                                    <div class="row">
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box  patteren1">
                                             <div class="menu-heading patteren1">
                                                <h4>Traditional PR</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">MEDIA RELATIONS PR</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">PERSONAL PR</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">COMMUNITY RELATIONS PR</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">CELEBRITY & INFLUENCER PR</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">EMPLOYEE COMMUNICATIONS PR</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box patteren2">
                                             <div class="menu-heading patteren2">
                                                <h4>Digital PR</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">FASHION PR</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">BEAUTY/ LIFESTYLE PR</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">CONSUMER PR</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">LAUNCH PR</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">LUXURY PR</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box patteren3">
                                             <div class="menu-heading patteren3">
                                                <h4>Press/Media</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">ARTICLES</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">MEDIA</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">INFLUENCER</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">PRESS RELEASE</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">RELEASES </a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box patteren4">
                                             <div class="menu-heading patteren4">
                                                <h4>Learn Moris PR</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">Learn Travel & Hospitality Pr</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">Learn Food & Beverage Pr</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">Learn Health & Welness Pr</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">Learn Entertainment & Sports Pr</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">Learn Media Relations Pr</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <!-- moris mega menu end -->
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link" href="#">DIGITAL MARKETING
                                    <svg xmlns="" xmlns:xlink="" version="1.1" id="Layer_1" x="0px" y="0px" viewBox="0 0 330 330" style="enable-background:new 0 0 330 330;" xml:space="preserve">
                                       <path id="XMLID_225_" d="M325.607,79.393c-5.857-5.857-15.355-5.858-21.213,0.001l-139.39,139.393L25.607,79.393  c-5.857-5.857-15.355-5.858-21.213,0.001c-5.858,5.858-5.858,15.355,0,21.213l150.004,150c2.813,2.813,6.628,4.393,10.606,4.393  s7.794-1.581,10.606-4.394l149.996-150C331.465,94.749,331.465,85.251,325.607,79.393z"></path>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                    </svg>
                                 </a>
                                 <!-- moris mega menu start -->
                                 <div class="moris-mega-menu">
                                    <div class="row">
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box  patteren1">
                                             <div class="menu-heading patteren1">
                                                <h4>Social Media Management</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">SOCIAL MEDIA MANAGEMENT</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">SOCIAL MEDIA ADVERTISING</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">ENTERPRISE SOCIAL MEDIA ADVERTISING</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">SOCIAL MEDIA DESIGN</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">YOUTUBE SOCIAL MEDIA ADVERTISING</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box patteren2">
                                             <div class="menu-heading patteren2">
                                                <h4>Lead Genration</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">AFFILIATE MARKETING</a></h3>
                                                         <p>Performance-based growth</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">B2B TELE MARKETING</a></h3>
                                                         <p>Unrivalled lead conversion rates</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">EFFECTIVE LEAD GENERATION</a></h3>
                                                         <p>Increase result, make life easier</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">INBOUND MARKETING</a></h3>
                                                         <p>Unrivalled lead conversion rate</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">GUARANTEED LEADS </a></h3>
                                                         <p>Pay for lead not for click</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box patteren3">
                                             <div class="menu-heading patteren3">
                                                <h4>SEO Services</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">ORGANIC SEARCH</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">SEO SERVICES</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">ENTERPRISE SEO SERVICES</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">LOCAL SEO SERVICES</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">GOOGLE LOCAL  ADS MANAGEMENT</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box patteren4">
                                             <div class="menu-heading patteren4">
                                                <h4>Learn Moris PR</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">Learn Travel & Hospitality Pr</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">Learn Food & Beverage Pr</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">Learn Health & Welness Pr</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">Learn Entertainment & Sports Pr</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">Learn Media Relations Pr</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <!-- moris mega menu end -->
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link" href="#">UX & INTERACTIVE 
                                    <svg xmlns="" xmlns:xlink="" version="1.1" id="Layer_1" x="0px" y="0px" viewBox="0 0 330 330" style="enable-background:new 0 0 330 330;" xml:space="preserve">
                                       <path id="XMLID_225_" d="M325.607,79.393c-5.857-5.857-15.355-5.858-21.213,0.001l-139.39,139.393L25.607,79.393  c-5.857-5.857-15.355-5.858-21.213,0.001c-5.858,5.858-5.858,15.355,0,21.213l150.004,150c2.813,2.813,6.628,4.393,10.606,4.393  s7.794-1.581,10.606-4.394l149.996-150C331.465,94.749,331.465,85.251,325.607,79.393z"></path>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                    </svg>
                                 </a>
                                 <!-- moris mega menu start -->
                                 <div class="moris-mega-menu">
                                    <div class="row">
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box  patteren1">
                                             <div class="menu-heading patteren1">
                                                <h4>UX /UI & Web Design</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">UI/UX DESIGNS</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">UX WEBSITE REDESIGN</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">USER EXPERIENCE TESTING</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">LANDING PAGES & FUNNELS</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">CONVERSION RATE OPTIMIZATION</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box patteren2">
                                             <div class="menu-heading patteren2">
                                                <h4>Content Marketing</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">SEO COPYWRITING</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">CONTENT MARKETING SERVICES</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">PERSONALIZED WEB CONTENT</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">INFOGRAPHICS & MOTION GRAPHICS</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">WEB VIDEO PRODUCTION SERVICES</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box patteren3">
                                             <div class="menu-heading patteren3">
                                                <h4>Developement</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">MOBILE APPS & GAMES</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">WEB DEVELOPMENT, AI, AWS</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">SHOPIFY ECOMMERCE DEVELOPMENT</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">WEB INFRASTRUCTURE & MAINTENANCE</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">CONTENT MANAGEMENT SYSTEMS</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box patteren4">
                                             <div class="menu-heading patteren4">
                                                <h4>Learn Moris PR</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">OUR UX DESIGN PORTFOLIO</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">MY WEBSITE DOESN'T DRIVE LEADS</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">MY WEBSITE TRAFFIC IS GOING DOWN</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">MY WEBSITE DOESN'T CONVERT</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">MY WEBSITE ISN'T MAKING MONEY</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <!-- moris mega menu end -->
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link " href="#">ECOMMERCE
                                    <svg xmlns="" xmlns:xlink="" version="1.1" id="Layer_1" x="0px" y="0px" viewBox="0 0 330 330" style="enable-background:new 0 0 330 330;" xml:space="preserve">
                                       <path id="XMLID_225_" d="M325.607,79.393c-5.857-5.857-15.355-5.858-21.213,0.001l-139.39,139.393L25.607,79.393  c-5.857-5.857-15.355-5.858-21.213,0.001c-5.858,5.858-5.858,15.355,0,21.213l150.004,150c2.813,2.813,6.628,4.393,10.606,4.393  s7.794-1.581,10.606-4.394l149.996-150C331.465,94.749,331.465,85.251,325.607,79.393z"></path>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                    </svg>
                                 </a>
                                 <!-- moris mega menu start -->
                                 <div class="moris-mega-menu">
                                    <div class="row">
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box  patteren1">
                                             <div class="menu-heading patteren1">
                                                <h4>Digital Marketing</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">ECOMMERCE SEO SERVICES</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">ECOMMERCE PPC SERVICES</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">ECOMMERCE SOCIAL MEDIA ADVERTISING</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">D2C SOCIAL MEDIA ADVERTISING</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">VIDEO COMMERCE, CONNECTED TV & OTT</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box patteren2">
                                             <div class="menu-heading patteren2">
                                                <h4>Commerce Platforms</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">FACEBOOK MARKETPLACE FOR BUSINESS</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">SHOPIFY OPTIMIZATION SERVICES</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">TARGET PLUS™ MARKETPLACE MANAGEMENT</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">WALMART MARKETPLACE ADVERTISING</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">SHOPPING FEED AUTOMATION</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box patteren3">
                                             <div class="menu-heading patteren3">
                                                <h4>Amazon</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">AMAZON SEO & PRODUCT OPTIMIZATION</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">AMAZON ADVERTISING MANAGEMENT</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">AMAZON STORES & MARKETPLACE LAUNCH</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">AMAZON MARKETING RESOURCES</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">HOW TO OPEN AN AMAZON STOREFRONT</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box patteren4">
                                             <div class="menu-heading patteren4">
                                                <h4>B2B Ecommerce</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">B2B ECOMMERCE ENABLEMENT</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">DIGITAL TRANSFORMATION SOLUTIONS</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">ECOMMERCE PIM</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">B2B AR & VR SOLUTIONS</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">WHERE TO SELL ONLINE IN</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <!-- moris mega menu end -->
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link " href="#">CELEBRITY & INFLUENCER 
                                    <svg xmlns="" xmlns:xlink="" version="1.1" id="Layer_1" x="0px" y="0px" viewBox="0 0 330 330" style="enable-background:new 0 0 330 330;" xml:space="preserve">
                                       <path id="XMLID_225_" d="M325.607,79.393c-5.857-5.857-15.355-5.858-21.213,0.001l-139.39,139.393L25.607,79.393  c-5.857-5.857-15.355-5.858-21.213,0.001c-5.858,5.858-5.858,15.355,0,21.213l150.004,150c2.813,2.813,6.628,4.393,10.606,4.393  s7.794-1.581,10.606-4.394l149.996-150C331.465,94.749,331.465,85.251,325.607,79.393z"></path>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                    </svg>
                                 </a>
                                 <!-- moris mega menu start -->
                                 <div class="moris-mega-menu">
                                    <div class="row">
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box  patteren1">
                                             <div class="menu-heading patteren1">
                                                <h4>Influencers</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">CELEBRITY INTERVIEWS </a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">BRAND RECORDED VIDEO</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">CELEBRITY GIGS</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">CELEBRITY STAR HOUR</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">CELEBRITY E-INVITES</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box patteren2">
                                             <div class="menu-heading patteren2">
                                                <h4>Brand Endorsement</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">BOOK FOR  EVENT</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">BEAUTY/ LIFESTYLE PR</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">CONSUMER PR</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">LAUNCH PR</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">LUXURY PR</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box patteren3">
                                             <div class="menu-heading patteren3">
                                                <h4>Book Celebrities</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">ARTICLES</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">MEDIA</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">INFLUENCER</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">PRESS RELEASE</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">RELEASES </a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box patteren4">
                                             <div class="menu-heading patteren4">
                                                <h4>Celebrities Bytes</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">Learn Travel & Hospitality Pr</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">Learn Food & Beverage Pr</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">Learn Health & Welness Pr</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">Learn Entertainment & Sports Pr</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">Learn Media Relations Pr</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <!-- moris mega menu end -->
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link " href="#">WHO WE ARE
                                    <svg xmlns="" xmlns:xlink="" version="1.1" id="Layer_1" x="0px" y="0px" viewBox="0 0 330 330" style="enable-background:new 0 0 330 330;" xml:space="preserve">
                                       <path id="XMLID_225_" d="M325.607,79.393c-5.857-5.857-15.355-5.858-21.213,0.001l-139.39,139.393L25.607,79.393  c-5.857-5.857-15.355-5.858-21.213,0.001c-5.858,5.858-5.858,15.355,0,21.213l150.004,150c2.813,2.813,6.628,4.393,10.606,4.393  s7.794-1.581,10.606-4.394l149.996-150C331.465,94.749,331.465,85.251,325.607,79.393z"></path>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                    </svg>
                                 </a>
                                 <!-- moris mega menu start -->
                                 <div class="moris-mega-menu">
                                    <div class="row">
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box  patteren1">
                                             <div class="menu-heading patteren1">
                                                <h4>Who We Are</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">WHO WE ARE</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">LOCATIONS</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">CAREERS (WE ARE HIRING!)</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">ABOUT US</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">CONTACT INFO</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box patteren2">
                                             <div class="menu-heading patteren2">
                                                <h4>Legal</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">TERMS OF USE</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">PRIVACY POLICY</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">COPYRIGHT POLICY</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">CONTACT US</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">EMI & REFUND POLICY</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box patteren3">
                                             <div class="menu-heading patteren3">
                                                <h4>Pricing Guides</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">SOCIAL MEDIA PRICING</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">SEO Optimisation PRICING </a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">UI/UX Website PRICING</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">EMAIL MARKETING PRICING</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">LOCAL SEO PRICING</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box patteren4">
                                             <div class="menu-heading patteren4">
                                                <h4>Over Partners</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">MORIS  TALENT HUNT</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">MORIS GIGS</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">BOOK MORIS</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">SMS MANAGEMENT</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">EDUCATE FIRST</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <!-- moris mega menu end -->
                              </li>
                           </ul>
                           <form class="d-flex align-items">
                              <div class="get-purposal">
                                 <a href="#" class="get-btn">GET A PROPOSAL
                                 <img class="rocket" src="images/rocket-icon.png" alt="">
                                 <img class="cloud" src="images/cloud-patteren.png" alt="">
                                 </a>
                              </div>
                              <a href="#" class="openBtn" onclick="openSearch()">
                                 <img src="images/search-icon.png" alt="search-icon">
                              </a>
                              <span class="open_nav" onclick="openNav()">&#9776;</span>
                           </form>
                        </div>
                        <!-- for mobile view start-->
                        <div id="mobileview-menu" class="moris-mobile-view hide">
                           <!-- top navigation start -->
                           <div class="top-navigation">
                              <div class="container-fluid">
                                 <div class="row align-items">
                                    <div class="col-lg-12">
                                       <ul class="moris-celebrity">
                                          <li>
                                             <a href="#">Celebrity Directory</a>
                                             <span>...</span>
                                             <a href="#">Enroll as Celeb </a>
                                          </li>
                                          <!-- <li>
                                             <a href="https://www.morisgigs.in/login" class="manager-login">Manager Login</a>
                                          </li> -->
                                       </ul>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <!-- top navigation end -->
                           <a href="javascript:void(0)" class="closebtn" onclick="closeMobile()">×</a>
                           <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                              <li class="nav-item">
                                 <a class="nav-link" href="#">MORIS PR
                                    <svg xmlns="" xmlns:xlink="" version="1.1" id="Layer_1" x="0px" y="0px" viewBox="0 0 330 330" style="enable-background:new 0 0 330 330;" xml:space="preserve">
                                       <path id="XMLID_225_" d="M325.607,79.393c-5.857-5.857-15.355-5.858-21.213,0.001l-139.39,139.393L25.607,79.393  c-5.857-5.857-15.355-5.858-21.213,0.001c-5.858,5.858-5.858,15.355,0,21.213l150.004,150c2.813,2.813,6.628,4.393,10.606,4.393  s7.794-1.581,10.606-4.394l149.996-150C331.465,94.749,331.465,85.251,325.607,79.393z"></path>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                    </svg>
                                 </a>
                                 <!-- moris mega menu start -->
                                 <div class="moris-mega-menu">
                                    <div class="row">
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box  patteren1">
                                             <div class="menu-heading patteren1">
                                                <h4>Traditional PR</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">MEDIA RELATIONS PR</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">PERSONAL PR</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">COMMUNITY RELATIONS PR</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">CELEBRITY & INFLUENCER PR</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">EMPLOYEE COMMUNICATIONS PR</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box patteren2">
                                             <div class="menu-heading patteren2">
                                                <h4>Digital PR</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">FASHION PR</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">BEAUTY/ LIFESTYLE PR</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">CONSUMER PR</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">LAUNCH PR</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">LUXURY PR</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box patteren3">
                                             <div class="menu-heading patteren3">
                                                <h4>Press/Media</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">ARTICLES</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">MEDIA</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">INFLUENCER</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">PRESS RELEASE</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">RELEASES </a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box patteren4">
                                             <div class="menu-heading patteren4">
                                                <h4>Learn Moris PR</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">Learn Travel & Hospitality Pr</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">Learn Food & Beverage Pr</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">Learn Health & Welness Pr</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">Learn Entertainment & Sports Pr</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">Learn Media Relations Pr</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <!-- moris mega menu end -->
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link" href="#">DIGITAL MARKETING
                                    <svg xmlns="" xmlns:xlink="" version="1.1" id="Layer_1" x="0px" y="0px" viewBox="0 0 330 330" style="enable-background:new 0 0 330 330;" xml:space="preserve">
                                       <path id="XMLID_225_" d="M325.607,79.393c-5.857-5.857-15.355-5.858-21.213,0.001l-139.39,139.393L25.607,79.393  c-5.857-5.857-15.355-5.858-21.213,0.001c-5.858,5.858-5.858,15.355,0,21.213l150.004,150c2.813,2.813,6.628,4.393,10.606,4.393  s7.794-1.581,10.606-4.394l149.996-150C331.465,94.749,331.465,85.251,325.607,79.393z"></path>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                    </svg>
                                 </a>
                                 <!-- moris mega menu start -->
                                 <div class="moris-mega-menu">
                                    <div class="row">
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box  patteren1">
                                             <div class="menu-heading patteren1">
                                                <h4>Social Media Management</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">SOCIAL MEDIA MANAGEMENT</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">SOCIAL MEDIA ADVERTISING</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">ENTERPRISE SOCIAL MEDIA ADVERTISING</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">SOCIAL MEDIA DESIGN</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">YOUTUBE SOCIAL MEDIA ADVERTISING</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box patteren2">
                                             <div class="menu-heading patteren2">
                                                <h4>Lead Genration</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">AFFILIATE MARKETING</a></h3>
                                                         <p>Performance-based growth</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">B2B TELE MARKETING</a></h3>
                                                         <p>Unrivalled lead conversion rates</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">EFFECTIVE LEAD GENERATION</a></h3>
                                                         <p>Increase result, make life easier</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">INBOUND MARKETING</a></h3>
                                                         <p>Unrivalled lead conversion rate</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">GUARANTEED LEADS </a></h3>
                                                         <p>Pay for lead not for click</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box patteren3">
                                             <div class="menu-heading patteren3">
                                                <h4>SEO Services</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">ORGANIC SEARCH</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">SEO SERVICES</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">ENTERPRISE SEO SERVICES</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">LOCAL SEO SERVICES</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">GOOGLE LOCAL  ADS MANAGEMENT</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box patteren4">
                                             <div class="menu-heading patteren4">
                                                <h4>Learn Moris PR</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">Learn Travel & Hospitality Pr</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">Learn Food & Beverage Pr</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">Learn Health & Welness Pr</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">Learn Entertainment & Sports Pr</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">Learn Media Relations Pr</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <!-- moris mega menu end -->
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link" href="#">UX & INTERACTIVE 
                                    <svg xmlns="" xmlns:xlink="" version="1.1" id="Layer_1" x="0px" y="0px" viewBox="0 0 330 330" style="enable-background:new 0 0 330 330;" xml:space="preserve">
                                       <path id="XMLID_225_" d="M325.607,79.393c-5.857-5.857-15.355-5.858-21.213,0.001l-139.39,139.393L25.607,79.393  c-5.857-5.857-15.355-5.858-21.213,0.001c-5.858,5.858-5.858,15.355,0,21.213l150.004,150c2.813,2.813,6.628,4.393,10.606,4.393  s7.794-1.581,10.606-4.394l149.996-150C331.465,94.749,331.465,85.251,325.607,79.393z"></path>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                    </svg>
                                 </a>
                                 <!-- moris mega menu start -->
                                 <div class="moris-mega-menu">
                                    <div class="row">
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box  patteren1">
                                             <div class="menu-heading patteren1">
                                                <h4>UX /UI & Web Design</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">UI/UX DESIGNS</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">UX WEBSITE REDESIGN</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">USER EXPERIENCE TESTING</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">LANDING PAGES & FUNNELS</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">CONVERSION RATE OPTIMIZATION</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box patteren2">
                                             <div class="menu-heading patteren2">
                                                <h4>Content Marketing</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">SEO COPYWRITING</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">CONTENT MARKETING SERVICES</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">PERSONALIZED WEB CONTENT</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">INFOGRAPHICS & MOTION GRAPHICS</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">WEB VIDEO PRODUCTION SERVICES</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box patteren3">
                                             <div class="menu-heading patteren3">
                                                <h4>Developement</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">MOBILE APPS & GAMES</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">WEB DEVELOPMENT, AI, AWS</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">SHOPIFY ECOMMERCE DEVELOPMENT</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">WEB INFRASTRUCTURE & MAINTENANCE</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">CONTENT MANAGEMENT SYSTEMS</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box patteren4">
                                             <div class="menu-heading patteren4">
                                                <h4>Learn Moris PR</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">OUR UX DESIGN PORTFOLIO</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">MY WEBSITE DOESN'T DRIVE LEADS</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">MY WEBSITE TRAFFIC IS GOING DOWN</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">MY WEBSITE DOESN'T CONVERT</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">MY WEBSITE ISN'T MAKING MONEY</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <!-- moris mega menu end -->
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link " href="#">ECOMMERCE
                                    <svg xmlns="" xmlns:xlink="" version="1.1" id="Layer_1" x="0px" y="0px" viewBox="0 0 330 330" style="enable-background:new 0 0 330 330;" xml:space="preserve">
                                       <path id="XMLID_225_" d="M325.607,79.393c-5.857-5.857-15.355-5.858-21.213,0.001l-139.39,139.393L25.607,79.393  c-5.857-5.857-15.355-5.858-21.213,0.001c-5.858,5.858-5.858,15.355,0,21.213l150.004,150c2.813,2.813,6.628,4.393,10.606,4.393  s7.794-1.581,10.606-4.394l149.996-150C331.465,94.749,331.465,85.251,325.607,79.393z"></path>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                    </svg>
                                 </a>
                                 <!-- moris mega menu start -->
                                 <div class="moris-mega-menu">
                                    <div class="row">
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box  patteren1">
                                             <div class="menu-heading patteren1">
                                                <h4>Digital Marketing</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">ECOMMERCE SEO SERVICES</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">ECOMMERCE PPC SERVICES</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">ECOMMERCE SOCIAL MEDIA ADVERTISING</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">D2C SOCIAL MEDIA ADVERTISING</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">VIDEO COMMERCE, CONNECTED TV & OTT</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box patteren2">
                                             <div class="menu-heading patteren2">
                                                <h4>Commerce Platforms</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">FACEBOOK MARKETPLACE FOR BUSINESS</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">SHOPIFY OPTIMIZATION SERVICES</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">TARGET PLUS™ MARKETPLACE MANAGEMENT</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">WALMART MARKETPLACE ADVERTISING</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">SHOPPING FEED AUTOMATION</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box patteren3">
                                             <div class="menu-heading patteren3">
                                                <h4>Amazon</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">AMAZON SEO & PRODUCT OPTIMIZATION</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">AMAZON ADVERTISING MANAGEMENT</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">AMAZON STORES & MARKETPLACE LAUNCH</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">AMAZON MARKETING RESOURCES</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">HOW TO OPEN AN AMAZON STOREFRONT</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box patteren4">
                                             <div class="menu-heading patteren4">
                                                <h4>B2B Ecommerce</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">B2B ECOMMERCE ENABLEMENT</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">DIGITAL TRANSFORMATION SOLUTIONS</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">ECOMMERCE PIM</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">B2B AR & VR SOLUTIONS</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">WHERE TO SELL ONLINE IN</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <!-- moris mega menu end -->
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link " href="#">CELEBRITY & INFLUENCER 
                                    <svg xmlns="" xmlns:xlink="" version="1.1" id="Layer_1" x="0px" y="0px" viewBox="0 0 330 330" style="enable-background:new 0 0 330 330;" xml:space="preserve">
                                       <path id="XMLID_225_" d="M325.607,79.393c-5.857-5.857-15.355-5.858-21.213,0.001l-139.39,139.393L25.607,79.393  c-5.857-5.857-15.355-5.858-21.213,0.001c-5.858,5.858-5.858,15.355,0,21.213l150.004,150c2.813,2.813,6.628,4.393,10.606,4.393  s7.794-1.581,10.606-4.394l149.996-150C331.465,94.749,331.465,85.251,325.607,79.393z"></path>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                    </svg>
                                 </a>
                                 <!-- moris mega menu start -->
                                 <div class="moris-mega-menu">
                                    <div class="row">
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box  patteren1">
                                             <div class="menu-heading patteren1">
                                                <h4>Influencers</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">CELEBRITY INTERVIEWS </a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">BRAND RECORDED VIDEO</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">CELEBRITY GIGS</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">CELEBRITY STAR HOUR</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">CELEBRITY E-INVITES</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box patteren2">
                                             <div class="menu-heading patteren2">
                                                <h4>Brand Endorsement</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">BOOK FOR  EVENT</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">BEAUTY/ LIFESTYLE PR</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">CONSUMER PR</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">LAUNCH PR</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">LUXURY PR</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box patteren3">
                                             <div class="menu-heading patteren3">
                                                <h4>Book Celebrities</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">ARTICLES</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">MEDIA</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">INFLUENCER</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">PRESS RELEASE</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">RELEASES </a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box patteren4">
                                             <div class="menu-heading patteren4">
                                                <h4>Celebrities Bytes</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">Learn Travel & Hospitality Pr</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">Learn Food & Beverage Pr</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">Learn Health & Welness Pr</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">Learn Entertainment & Sports Pr</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">Learn Media Relations Pr</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <!-- moris mega menu end -->
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link " href="#">WHO WE ARE
                                    <svg xmlns="" xmlns:xlink="" version="1.1" id="Layer_1" x="0px" y="0px" viewBox="0 0 330 330" style="enable-background:new 0 0 330 330;" xml:space="preserve">
                                       <path id="XMLID_225_" d="M325.607,79.393c-5.857-5.857-15.355-5.858-21.213,0.001l-139.39,139.393L25.607,79.393  c-5.857-5.857-15.355-5.858-21.213,0.001c-5.858,5.858-5.858,15.355,0,21.213l150.004,150c2.813,2.813,6.628,4.393,10.606,4.393  s7.794-1.581,10.606-4.394l149.996-150C331.465,94.749,331.465,85.251,325.607,79.393z"></path>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                       <g></g>
                                    </svg>
                                 </a>
                                 <!-- moris mega menu start -->
                                 <div class="moris-mega-menu">
                                    <div class="row">
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box  patteren1">
                                             <div class="menu-heading patteren1">
                                                <h4>Who We Are</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">WHO WE ARE</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">LOCATIONS</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">CAREERS (WE ARE HIRING!)</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">ABOUT US</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">CONTACT INFO</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box patteren2">
                                             <div class="menu-heading patteren2">
                                                <h4>Legal</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">TERMS OF USE</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">PRIVACY POLICY</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">COPYRIGHT POLICY</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">CONTACT US</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">EMI & REFUND POLICY</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box patteren3">
                                             <div class="menu-heading patteren3">
                                                <h4>Pricing Guides</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">SOCIAL MEDIA PRICING</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">SEO Optimisation PRICING </a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">UI/UX Website PRICING</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">EMAIL MARKETING PRICING</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">LOCAL SEO PRICING</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                          <div class="menu-box patteren4">
                                             <div class="menu-heading patteren4">
                                                <h4>Over Partners</h4>
                                             </div>
                                             <ul>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">MORIS  TALENT HUNT</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">MORIS GIGS</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">BOOK MORIS</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">SMS MANAGEMENT</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li>
                                                   <div class="menu-desc">
                                                      <div class="icon">
                                                         <i class="fas fa-arrow-up"></i>
                                                      </div>
                                                      <div class="text-holder">
                                                         <h3><a href="#">EDUCATE FIRST</a></h3>
                                                         <p>Tagline here this is the deming slogan</p>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <!-- moris mega menu end -->
                              </li>
                           </ul>
                           <form class="d-flex align-items">
                              <div class="get-purposal">
                                 <a href="#" class="get-btn">GET A PROPOSAL
                                 <img class="rocket" src="images/rocket-icon.png" alt="">
                                 <img class="cloud" src="images/cloud-patteren.png" alt="">
                                 </a>
                              </div>
                              <a href="#" class="openBtn" onclick="openSearch()">
                                 <img src="images/search-icon.png" alt="search-icon">
                              </a>
                              <span class="open_nav" onclick="openNav()">&#9776;</span>
                           </form>
                           
                        </div>
                        <!-- for mobile view end  -->
                     </div>
                  </nav>
                 </div>
              </div>
           </div>
           <!-- moris seraCH BAR START -->
           <div id="searchOverlay" class="overlay">
            <span class="closebtn" onclick="closeSearch()" title="Close Overlay">×</span>
            <div class="overlay-content">
               <form >
                  <input type="text" placeholder="Search.." name="search">
                  <button type="submit"><i class="fa fa-search"></i></button>
               </form>
            </div>
            </div>
           <!-- moris side bar start -->
           <div id="morisSidenav" class="moris-sidenav">
               <div class="sidenav-description">
                  <div class="logo-area">
                     <a href="http://morispr.in/" class="moris-logo">
                        <img src="images/moris-logo.png" alt="moris-logo">
                     </a>
                     <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
                  </div>
                  <p>
                     Brands need to do more than communicate, they need to connect. That requires equal parts art and science. MORIS PR is the rare combination of both.
                  </p>
                  <ul>
                     <li>
                        <div class="caption-holder">
                           <div class="icon">
                              <img src="images/location-icon.png" alt="">
                           </div>
                           <div class="text-holder">
                              <h5>Reach us:</h5>
                              <p>1010 Grand Avenue, New York, USA</p>
                           </div>
                        </div>
                     </li>
                     <li>
                        <div class="caption-holder">
                           <div class="icon">
                              <img src="images/comments-icon.png" alt="">
                           </div>
                           <div class="text-holder">
                              <h5>Reach us:</h5>
                              <p>business@morispr.com</p>
                           </div>
                        </div>
                     </li>
                     <li>
                        <div class="caption-holder">
                           <div class="icon">
                              <img src="images/phone-icon.png" alt="">
                           </div>
                           <div class="text-holder">
                              <h5>Call us:</h5>
                              <p>+92-3130-000-684</p>
                           </div>
                        </div>
                     </li>
                  </ul>
                  <div class="subcribed-holder">
                     <h3>Get Subscribed!</h3>
                     <form action="">
                        <div class="form-group">
                           <input type="text" placeholder="Email">
                        </div>
                        <div class="form-group">
                           <button type="submit" class="sub-btn">SUBSCRIBE NOW <i class="fas fa-long-arrow-alt-right"></i></button>
                        </div>
                     </form>
                     <h3>Follow us on</h3>
                     <ul class="moris-social">
                        <li>
                           <a href="#"><i class="fab fa-facebook-f"></i></a>
                        </li>
                        <li>
                           <a href="#"><i class="fab fa-twitter"></i></a>
                        </li>
                        <li>
                           <a href="#"><i class="fab fa-linkedin-in"></i></a>
                        </li>
                        <li>
                           <a href="#"><i class="fab fa-pinterest-p"></i></a>
                        </li>
                        <li>
                           <a href="#"><i class="far fa-user"></i></a>
                        </li>
                     </ul>
                  </div>
               </div>
            </div>
            <!-- moris side bar end -->
        </div>
        <!-- main header end -->
      </header>