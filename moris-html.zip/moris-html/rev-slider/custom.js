// for moris slider

function setREVStartSize(e){
         //window.requestAnimationFrame(function() {				 
         	window.RSIW = window.RSIW===undefined ? window.innerWidth : window.RSIW;	
         	window.RSIH = window.RSIH===undefined ? window.innerHeight : window.RSIH;	
         	try {								
         		var pw = document.getElementById(e.c).parentNode.offsetWidth,
         			newh;
         		pw = pw===0 || isNaN(pw) ? window.RSIW : pw;
         		e.tabw = e.tabw===undefined ? 0 : parseInt(e.tabw);
         		e.thumbw = e.thumbw===undefined ? 0 : parseInt(e.thumbw);
         		e.tabh = e.tabh===undefined ? 0 : parseInt(e.tabh);
         		e.thumbh = e.thumbh===undefined ? 0 : parseInt(e.thumbh);
         		e.tabhide = e.tabhide===undefined ? 0 : parseInt(e.tabhide);
         		e.thumbhide = e.thumbhide===undefined ? 0 : parseInt(e.thumbhide);
         		e.mh = e.mh===undefined || e.mh=="" || e.mh==="auto" ? 0 : parseInt(e.mh,0);		
         		if(e.layout==="fullscreen" || e.l==="fullscreen") 						
         			newh = Math.max(e.mh,window.RSIH);					
         		else{					
         			e.gw = Array.isArray(e.gw) ? e.gw : [e.gw];
         			for (var i in e.rl) if (e.gw[i]===undefined || e.gw[i]===0) e.gw[i] = e.gw[i-1];					
         			e.gh = e.el===undefined || e.el==="" || (Array.isArray(e.el) && e.el.length==0)? e.gh : e.el;
         			e.gh = Array.isArray(e.gh) ? e.gh : [e.gh];
         			for (var i in e.rl) if (e.gh[i]===undefined || e.gh[i]===0) e.gh[i] = e.gh[i-1];
         								
         			var nl = new Array(e.rl.length),
         				ix = 0,						
         				sl;					
         			e.tabw = e.tabhide>=pw ? 0 : e.tabw;
         			e.thumbw = e.thumbhide>=pw ? 0 : e.thumbw;
         			e.tabh = e.tabhide>=pw ? 0 : e.tabh;
         			e.thumbh = e.thumbhide>=pw ? 0 : e.thumbh;					
         			for (var i in e.rl) nl[i] = e.rl[i]<window.RSIW ? 0 : e.rl[i];
         			sl = nl[0];									
         			for (var i in nl) if (sl>nl[i] && nl[i]>0) { sl = nl[i]; ix=i;}															
         			var m = pw>(e.gw[ix]+e.tabw+e.thumbw) ? 1 : (pw-(e.tabw+e.thumbw)) / (e.gw[ix]);					
         			newh =  (e.gh[ix] * m) + (e.tabh + e.thumbh);
         		}				
         		if(window.rs_init_css===undefined) window.rs_init_css = document.head.appendChild(document.createElement("style"));					
         		document.getElementById(e.c).height = newh+"px";
         		window.rs_init_css.innerHTML += "#"+e.c+"_wrapper { height: "+newh+"px }";				
         	} catch(e){
         		console.log("Failure at Presize of Slider:" + e)
         	}					   
         //});
          };
        //   

        setREVStartSize({c: 'rev_slider_8_1',rl:[1240,1024,778,480],el:[868,768,960,720],gw:[1240,1024,778,480],gh:[868,768,800,720],type:'standard',justify:'',layout:'fullwidth',mh:"868"});
        var	revapi8,
            tpj;
        function revinit_revslider81() {
        jQuery(function() {
            tpj = jQuery;
            revapi8 = tpj("#rev_slider_8_1");
            if(revapi8==undefined || revapi8.revolution == undefined){
                revslider_showDoubleJqueryError("rev_slider_8_1");
            }else{
                revapi8.revolution({
                    sliderLayout:"fullwidth",
                    visibilityLevels:"1240,1024,778,480",
                    gridwidth:"1240,1024,778,480",
                    gridheight:"868,768,800,720",
                    minHeight:868,
                    spinner:"spinner0",
                    perspective:600,
                    perspectiveType:"local",
                    editorheight:"868,768,960,720",
                    responsiveLevels:"1240,1024,778,480",
                    progressBar:{disableProgressBar:true},
                    navigation: {
                        mouseScrollNavigation:false,
                        onHoverStop:false,
                        touch: {
                            touchenabled:true,
                            touchOnDesktop:true
                        },
                        arrows: {
                            enable:true,
                            style:"custom",
                            left: {
        
                            },
                            right: {
        
                            }
                        }
                    },
                    parallax: {
                        levels:[5,10,15,20,25,30,35,40,45,46,47,48,49,50,51,55],
                        type:"mouse"
                    },
                    fallbacks: {
                        allowHTML5AutoPlayOnAndroid:true
                    },
                });
            }
            
        });
        } // End of RevInitScript
        var once_revslider81 = false;
        if (document.readyState === "loading") {document.addEventListener('readystatechange',function() { if((document.readyState === "interactive" || document.readyState === "complete") && !once_revslider81 ) { once_revslider81 = true; revinit_revslider81();}});} else {once_revslider81 = true; revinit_revslider81();}

        var htmlDivCss = unescape("%23rev_slider_8_1_wrapper%20.custom.tparrows%20%7B%0A%09cursor%3Apointer%3B%0A%09background%3A%23000%3B%0A%09background%3Argba%280%2C0%2C0%2C0.5%29%3B%0A%09width%3A40px%3B%0A%09height%3A40px%3B%0A%09position%3Aabsolute%3B%0A%09display%3Ablock%3B%0A%09z-index%3A1000%3B%0A%7D%0A%23rev_slider_8_1_wrapper%20.custom.tparrows%3Ahover%20%7B%0A%09background%3A%23000%3B%0A%7D%0A%23rev_slider_8_1_wrapper%20.custom.tparrows%3Abefore%20%7B%0A%09font-family%3A%20%27revicons%27%3B%0A%09font-size%3A15px%3B%0A%09color%3A%23fff%3B%0A%09display%3Ablock%3B%0A%09line-height%3A%2040px%3B%0A%09text-align%3A%20center%3B%0A%7D%0A%23rev_slider_8_1_wrapper%20.custom.tparrows.tp-leftarrow%3Abefore%20%7B%0A%09content%3A%20%27%5Ce824%27%3B%0A%7D%0A%23rev_slider_8_1_wrapper%20.custom.tparrows.tp-rightarrow%3Abefore%20%7B%0A%09content%3A%20%27%5Ce825%27%3B%0A%7D%0A%0A%0A");
        var htmlDiv = document.getElementById('rs-plugin-settings-inline-css');
        if(htmlDiv) {
            htmlDiv.innerHTML = htmlDiv.innerHTML + htmlDivCss;
        }else{
            var htmlDiv = document.createElement('div');
            htmlDiv.innerHTML = '<style>' + htmlDivCss + '<\/style>';
            document.getElementsByTagName('head')[0].appendChild(htmlDiv.childNodes[0]);
        }

        var htmlDivCss = unescape("%0A%0A%0A");
            var htmlDiv = document.getElementById('rs-plugin-settings-inline-css');
            if(htmlDiv) {
                htmlDiv.innerHTML = htmlDiv.innerHTML + htmlDivCss;
            }else{
                var htmlDiv = document.createElement('div');
                htmlDiv.innerHTML = '<style>' + htmlDivCss + '<\/style>';
                document.getElementsByTagName('head')[0].appendChild(htmlDiv.childNodes[0]);
            }

               
                  