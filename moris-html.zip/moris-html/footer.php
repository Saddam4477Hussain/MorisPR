      <footer class="moris-footer">
        <div class="top-footer">
          <div class="container">
            <div class="row">
              <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <div class="footer-logo">
                  <a href="#">
                    <img src="images/moris-logo.png" alt="">
                  </a>
                </div>
              </div>
              <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <div class="footer-social text-right">
                  <ul>
                      <li>
                          <a href="#"><i class="fab fa-facebook-f"></i></a>
                      </li>
                      <li>
                          <a href="#"><i class="fab fa-twitter"></i></a>
                      </li>
                      <li>
                          <a href="#"><i class="fab fa-linkedin-in"></i></a>
                      </li>
                      <li>
                          <a href="#"><i class="fab fa-pinterest-p"></i></a>
                      </li>
                      <li>
                          <a href="#"><i class="far fa-user"></i></a>
                      </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="footer-menu">
          <div class="container">
            <div class="row">
              <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                <div class="footer-nav first-child">
                  <h2>Company</h2>
                  <ul>
                    <li>
                      <a href="#"><i class="fas fa-arrow-up" aria-hidden="true"></i> Contact</a>
                    </li>
                    <li>
                      <a href="#"><i class="fas fa-arrow-up" aria-hidden="true"></i> Support</a>
                    </li>
                    <li>
                      <a href="#"><i class="fas fa-arrow-up" aria-hidden="true"></i> Latest Blog</a>
                    </li>
                    <li>
                      <a href="#"><i class="fas fa-arrow-up" aria-hidden="true"></i> Pricing</a>
                    </li>
                    <li>
                      <a href="#"><i class="fas fa-arrow-up" aria-hidden="true"></i> Privacy Policy</a>
                    </li>
                    <li>
                      <a href="#"><i class="fas fa-arrow-up" aria-hidden="true"></i> Book Celebrities</a>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                <div class="footer-nav second-child">
                  <h2>Solutions</h2>
                  <ul>
                    <li>
                      <a href="#"><i class="fas fa-arrow-up" aria-hidden="true"></i> PR Marketing</a>
                    </li>
                    <li>
                      <a href="#"><i class="fas fa-arrow-up" aria-hidden="true"></i> Influencers Marketing</a>
                    </li>
                    <li>
                      <a href="#"><i class="fas fa-arrow-up" aria-hidden="true"></i> Social Media Management</a>
                    </li>
                    <li>
                      <a href="#"><i class="fas fa-arrow-up" aria-hidden="true"></i> Digital Marketing</a>
                    </li>
                    <li>
                      <a href="#"><i class="fas fa-arrow-up" aria-hidden="true"></i> SEO Marketing</a>
                    </li>
                    <li>
                      <a href="#"><i class="fas fa-arrow-up" aria-hidden="true"></i> Lead Genration</a>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                <div class="footer-nav article">
                  <h2>Recent Articles</h2>
                  <ul>
                    <li>
                      <p>Twice profit than before there is wasn’t ever got in business</p>
                      <a href="#" class="theme-color"><i class="far fa-calendar"></i> July 19, 2018</a>
                    </li>
                    <li>
                      <p>Twice profit than before there is wasn’t ever got in business</p>
                      <a href="#" class="theme-color"><i class="far fa-calendar"></i> July 19, 2018</a>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                <div class="footer-nav">
                  <h2>Grow your Brand</h2>
                  <form action="">
                    <div class="form-group">
                      <input type="text" placeholder="Name">
                    </div>
                    <div class="form-group">
                      <input type="text" placeholder="Email">
                    </div>
                    <div class="form-group">
                      <input type="text" placeholder="Phone">
                    </div>
                    <div class="form-group">
                      <button type="submit">GET YOUR PROPOSAL <i class="fas fa-long-arrow-alt-right" aria-hidden="true"></i></button>
                    </div>
                  </form>
                </div>
              </div>
              <div class="col-lg-12">
                <div class="moris-partener">
                  <div class="row align-items">
                    <div class="col-lg-9 col-md-9 col-sm-8 col-xs-12">
                      <div class="partener-brand">
                        <ul>
                          <li>
                            <h2>Partnership :</h2>
                          </li>
                          <li>
                            <a href="http://www.smm-gulf.com/">
                              <img src="images/silma-market.png" alt="">
                            </a>
                          </li>
                          <li>
                            <a href="https://www.moristalenthunt.com/">
                              <img src="images/moris-talent.png" alt="">
                            </a>
                          </li>
                          <li>
                            <a href="https://bookmoris.com/">
                              <img src="images/book-moris.png" alt="">
                            </a>
                          </li>
                          <li>
                            <a href="https://www.morisgigs.com/">
                              <img src="images/moris-gigs.png" alt="">
                            </a>
                          </li>
                        </ul>
                      </div>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12">
                      <div class="payment-method text-right">
                        <ul>
                          <li>
                            <a href="#">
                              <img src="images/visa-icon.png" alt="">
                            </a>
                          </li>
                          <li>
                            <a href="#">
                              <img src="images/master-card-icon.png" alt="">
                            </a>
                          </li>
                          <li>
                            <a href="#">
                              <img src="images/maestro-icon.png" alt="">
                            </a>
                          </li>
                          <li>
                            <a href="#">
                              <img src="images/paypal-icon.png" alt="">
                            </a>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-lg-12">
                <div class="copyrights text-center">
                  <p>Copyrights By MorisPR - 2021. All Rights Reserved.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </footer>
      <script src="js/poper.js"></script>
      <script src="js/boostrap.min.js"></script>
      <!-- <script src="js/jquery.js"></script> -->
      <!-- libraries include for rev slider  -->
      <script src="rev-slider/jquery.min.js"></script>
      <script src="rev-slider/rbtools.min.js"></script>
      <script src="rev-slider/rs6.min.js"></script>
      <script src="rev-slider/custom.js"></script>
      <!-- libraries include for rev slider  -->
      <script src="js/calendar.js"></script>
      <script>
      AOS.init({
        easing: 'ease-in-out-sine'
      });
    </script>
    <!-- <script>

      $(window).scroll(function() {
        if ($(window).scrollTop() > 300) {
          btn.addClass('show');
        } else {
          btn.removeClass('show');
        }
      });

      btn.on('click', function(e) {
        e.preventDefault();
        $('html, body').animate({scrollTop:0}, '300');
      });
    </script> -->
   </body>
</html>