<?php include 'header.php';?>
    <!-- slider revolution start -->
    <div class="moris-rev-slider">
        <p class="rs-p-wp-fix"></p>
        <rs-module-wrap id="rev_slider_8_1_wrapper" data-source="gallery" style="background:transparent;padding:0;margin:0px auto;margin-top:0;margin-bottom:0;">
            <rs-arrow style="opacity: 1;transform: translate(20px, -20px);top: 50%;left: 0px;" class="tp-leftarrow tparrows custom  noSwipe"><i class="fas fa-chevron-left"></i></rs-arrow>
            <rs-arrow style="opacity: 1; transform: translate(-60px, -20px); top: 50%; left: 100%;" class="tp-rightarrow tparrows custom noSwipe"><i class="fas fa-chevron-right"></i></rs-arrow>
            <rs-module id="rev_slider_8_1" class=" rs-ov-hidden" style="" data-version="6.3.5">
            <rs-slides>
                <rs-slide data-key="rs-16" data-title="Slider" data-thumb="images/18fc4-slider-bg-1-100x50.jpg" data-duration="5120" data-anim="ei:d;eo:d;s:d;r:0;t:slideoverhorizontal;sl:d;">
                    <img src="images/moris-banner.png" title="Home Three" data-parallax="off" class="rev-slidebg" data-no-retina>
                    <!--
                        -->
                    <rs-layer id="slider-8-slide-16-layer-4" data-type="text" data-rsp_ch="on" data-xy="xo:108px,108px,50px,60px;y:m;yo:-81px,-81px,-97px,-110px;" 
                    data-text="s:24;l:22;fw:300;a:inherit;" data-dim="w:183px;h:32px;" data-frame_0="o:1;" data-frame_0_chars="d:5;y:100%;o:1;rZ:-35deg;" 
                    data-frame_0_mask="u:t;" data-frame_1="e:power4.inOut;st:2050;sp:2000;sR:2050;" data-frame_1_chars="d:5;" data-frame_1_mask="u:t;" 
                    data-frame_999="y:-50px;o:0;e:power4.inOut;st:w;sp:1000;sR:420;" style="z-index:11;font-family:DMSans-Medium;width:100%">PR Marketing 
                    </rs-layer>
                    <!--
                        -->
                    <rs-layer id="slider-8-slide-16-layer-5" data-type="text" data-rsp_ch="on" 
                    data-xy="xo:108px,108px,50px,60px;y:m;yo:-30px,-30px,-52px,-66px;" 
                    data-text="w:normal;s:56,56,35,35;l:61,61,40,35;fw:700,700,900,900;a:inherit;" 
                    data-dim="w:540px,540px,355px,100%;" data-frame_0="o:1;" 
                    data-frame_0_chars="d:5;y:100%;o:1;rZ:-35deg;" data-frame_0_mask="u:t;" 
                    data-frame_1="e:power4.inOut;st:2350;sp:2000;sR:2350;" data-frame_1_chars="d:5;" 
                    data-frame_1_mask="u:t;" 
                    data-frame_999="y:-100%;e:nothing;st:w;sR:20;" 
                    data-frame_999_mask="u:t;" style="z-index:12;font-family:DMSans-Medium;">Moris Public 
                    </rs-layer>
                    <!--
                        -->
                    <rs-layer id="slider-8-slide-16-layer-7" data-type="text" 
                    data-rsp_ch="on" data-xy="xo:108px,108px,46px,60px;y:m;yo:64px,64px,0,-20px;" 
                    data-text="w:normal;s:15;l:26;a:inherit;" data-dim="w:445px,445px,350px,364px;" 
                    data-frame_0="y:50px;" data-frame_1="e:power4.inOut;st:2650;sp:2000;sR:2650;" 
                    data-frame_999="y:-100%;e:nothing;st:w;sR:470;" 
                    data-frame_999_mask="u:t;" style="z-index:13;font-family:DMSans-Medium;">Share processes and data securely on a need to know basis 
                        need for reconciliation it combines. 
                    </rs-layer>
                    <!--
                        -->
                    <rs-layer id="slider-8-slide-16-layer-8" class="rev-btn" data-type="button" 
                    data-color="rgba(255,255,255,1)" data-xy="xo:108px,108px,44px,56px;y:m;yo:161px,161px,101px,70px;" 
                    data-text="w:normal;s:15;l:17;ls:1px,1px,0,0;fw:400,400,100,100;a:inherit,inherit,inherit,center;" 
                    data-dim="w:200px,200px,200px,150px;" 
                    data-rsp_bd="off" data-padding="t:21,21,21,15;r:45,45,51,30;b:21,21,21,15;l:45,45,51,30;" 
                    data-border="bor:3px,3px,3px,3px;" data-frame_0="y:50px;" 
                    data-frame_1="st:2950;sp:1500;sR:2950;" data-frame_999="y:-100%;e:nothing;st:w;sR:670;" 
                    data-frame_999_mask="u:t;" 
                    data-frame_hover="bgc:#00138e;boc:#000;bor:3px,3px,3px,3px;bos:solid;oX:50;oY:50;sp:500;e:power3.in;" 
                    style="z-index:14;background-color:#ef1855;font-family:DMSans-Medium;cursor:pointer;outline:none;
                    box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;">Get Started 
                    </rs-layer>
                    <!--
                        -->
                    <rs-layer id="slider-8-slide-16-layer-10" data-type="image" 
                    data-rsp_ch="on" data-xy="x:r;xo:-65px,-65px,5px,10px;yo:233px,233px,348px,405px;" 
                    data-text="l:22;a:inherit;" data-dim="w:578auto,578px,329px,223px;h:580px,580px,330px,224px;" 
                    data-frame_0="x:right;o:1;" data-frame_1="st:250;sp:1500;sR:250;" 
                    data-frame_999="x:-100%;st:w;sp:1000;sR:3370;" 
                    data-frame_999_mask="u:t;" style="z-index:5;"><img loading="lazy" src="images/876f8-monitor.png" width="578" height="580" data-no-retina> 
                    </rs-layer>
                    <!--
                        -->
                    <rs-layer id="slider-8-slide-16-layer-11" class="rs-pxl-1" data-type="image" 
                    data-rsp_ch="on" data-xy="xo:674px,674px,219px,219px;yo:220px,220px,181px,181px;" 
                    data-text="l:22;a:inherit;" data-dim="w:105px,105px,339auto,339auto;h:156px,156px,206px,206px;" 
                    data-vbility="t,t,f,f" data-frame_0="y:top;o:1;" 
                    data-frame_1="st:850;sp:1500;sR:850;" data-frame_999="x:100%;st:w;sp:1000;sR:2770;" 
                    data-frame_999_mask="u:t;" style="z-index:7;"><img loading="lazy" src="images/90488-level_up.png" width="105" height="156" data-no-retina> 
                    </rs-layer>
                    <!--
                        -->
                    <rs-layer id="slider-8-slide-16-layer-12" class="rs-pxl-2" data-type="image" data-rsp_ch="on" data-xy="xo:830px;yo:701px;" data-text="l:22;a:inherit;" data-dim="w:['186auto','186auto','186auto','186auto'];h:['159px','159px','159px','159px'];" data-vbility="t,t,f,f" data-frame_0="y:bottom;o:1;" data-frame_1="st:1150;sp:1500;sR:1150;" data-frame_999="x:100%;st:w;sp:1000;sR:2470;" data-frame_999_mask="u:t;" style="z-index:8;"><img loading="lazy" src="images/0f8eb-paper.png" width="186" height="159" data-no-retina> 
                    </rs-layer>
                    <!--
                        -->
                    <rs-layer id="slider-8-slide-16-layer-14" class="rs-pxl-1" data-type="image" data-rsp_ch="on" data-xy="xo:923px,923px,438px,438px;yo:243px,243px,120px,120px;" data-text="l:22;a:inherit;" data-dim="w:128px,128px,138auto,138auto;h:116px,116px,171px,171px;" data-vbility="t,t,f,f" data-frame_0="y:top;o:1;" data-frame_1="st:550;sp:1500;sR:550;" data-frame_999="x:-100%;st:w;sp:1000;sR:3070;" data-frame_999_mask="u:t;" style="z-index:6;"><img loading="lazy" src="images/4eb8d-cloud.png" width="128" height="116" data-no-retina> 
                    </rs-layer>
                    <!--
                        -->
                    <rs-layer id="slider-8-slide-16-layer-15" class="rs-pxl-1" data-type="image" data-rsp_ch="on" data-xy="xo:567px,567px,588px,588px;yo:450px,450px,214px,214px;" data-text="l:22;a:inherit;" data-dim="w:187auto,187auto,244px,244px;h:206px,206px,278px,278px;" data-vbility="t,t,f,f" data-frame_0="x:left;o:1;" data-frame_1="st:1450;sp:1500;sR:1450;" data-frame_999="x:100%;st:w;sp:1000;sR:2170;" data-frame_999_mask="u:t;" style="z-index:9;"><img loading="lazy" src="images/a85a2-speaker.png" width="187" height="206" data-no-retina> 
                    </rs-layer>
                    <!--
                        -->
                    <rs-layer id="slider-8-slide-16-layer-16" data-type="image" data-rsp_ch="on" data-xy="xo:765px;yo:422px;" data-text="l:22;a:inherit;" data-dim="w:['162','162','162','162'];h:['193','193','193','193'];" data-vbility="t,t,f,f" data-frame_0="sX:0.9;sY:0.9;" data-frame_1="st:1750;sp:1500;sR:1750;" data-frame_999="sX:0.7;sY:0.7;o:0;rZ:0deg;e:back.in;st:w;sp:1000;sR:1870;" data-frame_999_mask="u:t;" data-loop_0="xR:10;yR:10;oX:50;oY:50;" data-loop_999="xR:10;yR:10;crd:t;sp:2000;yys:t;yyf:t;" style="z-index:10;"><img loading="lazy" src="images/03353-search.png" width="162" height="193" data-no-retina> 
                    </rs-layer>
                    <!--
                        -->						
                </rs-slide>
                <rs-slide data-key="rs-17" data-title="Slide" data-thumb="images/665d1-slider-bg-2-100x50.jpg" data-duration="4060" data-anim="ei:d;eo:d;s:d;r:0;t:slideup;sl:d;">
                    <img src="images/moris-banner.png" title="Home Three" data-parallax="off" class="rev-slidebg" data-no-retina>
                    <!--
                        -->
                    <rs-layer id="slider-8-slide-17-layer-4" data-type="text" data-rsp_ch="on" 
                    data-xy="x:r,r,l,l;xo:398px,237px,60px,60px;y:m;yo:-123px,-219px,-136px,-100px;" 
                    data-text="s:24;l:22;fw:300;a:inherit;" data-dim="w:183px;h:32px;" 
                    data-frame_0="o:1;" data-frame_0_chars="d:5;x:-200px;o:0;skX:85px;" 
                    data-frame_1="e:power4.inOut;st:540;sp:2000;sR:540;" 
                    data-frame_1_chars="d:5;" data-frame_999="y:-50px;o:0;e:power4.inOut;st:w;sp:1000;sR:770;" 
                    style="z-index:5;font-family:DMSans-Medium;">Influencers Marketing 
                    </rs-layer>
                    <!--
                        -->
                    <rs-layer id="slider-8-slide-17-layer-5" data-type="text" 
                    data-rsp_ch="on" data-xy="x:r,r,l,l;xo:40px,-117px,60px,60px;y:m;yo:-30px,-124px,-100px,-66px;" 
                    data-text="w:normal;s:56,45,32,25;l:61,61,35,35;fw:700,900,900,900;a:inherit;" 
                    data-dim="w:540px,540px,419px,100%;h:auto,auto,37px,auto;" data-frame_0="o:1;" 
                    data-frame_0_chars="d:5;x:-200px;o:0;skX:85px;" data-frame_1="e:power4.inOut;st:850;sp:2000;sR:850;" 
                    data-frame_1_chars="d:5;" data-frame_999="y:-100%;e:nothing;st:w;sp:1000;sR:10;" 
                    data-frame_999_mask="u:t;" style="z-index:6;font-family:DMSans-Medium;">Social Media Management
                    </rs-layer>
                    <!--
                        -->
                    <rs-layer id="slider-8-slide-17-layer-7" data-type="text" data-rsp_ch="on" data-xy="x:r,r,l,l;xo:130px,2px,60px,60px;y:m;yo:72px,-27px,0,-20px;" data-text="w:normal;s:15;l:26;a:inherit;" data-dim="w:445px,418px,429px,350px;h:auto,auto,81px,auto;" data-frame_0="y:50px;" data-frame_1="e:power4.inOut;st:1070;sp:2000;sR:1070;" data-frame_999="y:-100%;e:nothing;st:w;sp:1000;sR:990;" data-frame_999_mask="u:t;" style="z-index:7;font-family:DMSans-Medium;">Share processes and data securely on a need to know basis 
                        need for reconciliation it combines. 
                    </rs-layer>
                    <!--
                        -->
                    <rs-layer id="slider-8-slide-17-layer-8" class="rev-btn" data-type="button" data-color="rgba(255,255,255,1)" data-rsp_ch="on" data-xy="x:r,l,l,l;xo:396px,604px,60px,60px;y:m,b,m,m;yo:152px,300px,101px,70px;" data-text="w:normal;s:15;l:17;ls:1px,0,0,0;fw:400,400,100,100;a:inherit,inherit,inherit,center;" data-dim="w:200px,200px,200px,150px;" data-padding="t:21,21,21,15;r:45,51,51,30;b:21,21,21,15;l:45,51,51,30;" data-border="bor:3px,3px,3px,3px;" data-frame_0="y:50px;" data-frame_1="st:1300;sp:1500;sR:1300;" data-frame_999="y:-100%;e:nothing;st:w;sp:1000;sR:1260;" data-frame_999_mask="u:t;" data-frame_hover="bgc:#00138e;boc:#000;bor:3px,3px,3px,3px;bos:solid;oX:50;oY:50;sp:500;e:power3.in;" style="z-index:8;background-color:#ef1855;font-family:DMSans-Medium;cursor:pointer;outline:none;box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;">Get Started 
                    </rs-layer>
                    <!--
                        -->
                    <rs-layer id="slider-8-slide-17-layer-19" data-type="image" data-rsp_ch="on" data-xy="xo:80px,62px,444px,89px;yo:182px,140px,332px,276px;" data-text="l:22;a:inherit;" data-dim="w:443,443auto,333px,293px;h:469,469px,353px,310px;" data-vbility="t,t,t,f" data-frame_0="y:bottom;o:1;" data-frame_1="st:1200;sp:1000;sR:1200;" data-frame_999="x:-100%;st:w;sp:1000;sR:1860;" data-frame_999_mask="u:t;" style="z-index:10;"><img loading="lazy" src="images/70952-laptop.png" width="443" height="469" data-no-retina> 
                    </rs-layer>
                    <!--
                        -->
                    <rs-layer id="slider-8-slide-17-layer-20" data-type="image" data-rsp_ch="on" data-xy="xo:446px,428px,464px,311px;yo:422px,380px,674px,441px;" data-text="l:22;a:inherit;" data-dim="w:117auto,117auto,117auto,76px;h:109px,109px,109px,71px;" data-frame_0="y:bottom;sX:2;sY:2;o:1;rZ:90deg;" data-frame_1="st:1500;sp:1000;sR:1500;" data-frame_999="y:100%;sX:0.7;sY:0.7;rZ:0deg;st:w;sp:1000;sR:1560;" data-frame_999_mask="u:t;" data-loop_0="xR:10;yR:10;oX:50;oY:50;" data-loop_999="xR:10;yR:10;crd:t;sp:2000;yys:t;yyf:t;" style="z-index:11;"><img loading="lazy" src="images/a3aeb-search.png" width="117" height="109" data-no-retina> 
                    </rs-layer>
                    <!--
                        -->
                    <rs-layer id="slider-8-slide-17-layer-21" class="rs-pxl-1" data-type="image" data-rsp_ch="on" data-xy="xo:404px,386px,431px,290px;yo:286px,244px,522px,344px;" data-text="l:22;a:inherit;" data-dim="w:199auto,199auto,199auto,138px;h:207px,207px,207px,165px;" data-vbility="t,t,f,f" data-frame_0="y:top;o:1;" data-frame_1="st:1000;sp:1000;sR:1000;" data-frame_999="x:100%;st:w;sp:1000;sR:2060;" data-frame_999_mask="u:t;" style="z-index:9;"><img loading="lazy" src="images/664cb-smartphone.png" width="199" height="207" data-no-retina> 
                    </rs-layer>
                    <!--
                        -->
                    <rs-layer id="slider-8-slide-17-layer-22" class="rs-pxl-1" data-type="image" data-rsp_ch="on" data-xy="xo:40px,22px,92px,39px;yo:550px,508px,770px,506px;" data-text="l:22;a:inherit;" data-dim="w:219auto,219auto,219auto,166px;h:153px,153px,153px,116px;" data-vbility="t,t,f,f" data-frame_0="sX:0.9;sY:0.9;" data-frame_1="e:power2.out;st:1800;sp:1000;sR:1800;" data-frame_999="x:100%;st:w;sp:1000;sR:1260;" data-frame_999_mask="u:t;" style="z-index:12;"><img loading="lazy" src="images/6ea25-pie.png" width="219" height="153" data-no-retina> 
                    </rs-layer>
                    <!--
                        -->
                    <rs-layer id="slider-8-slide-17-layer-23" class="rs-pxl-2" data-type="image" data-rsp_ch="on" data-xy="xo:21px,3px,55px,25px;yo:489px,447px,705px,461px;" data-text="l:22;a:inherit;" data-dim="w:118auto,118auto,118auto,82px;h:100px,100px,100px,69px;" data-vbility="t,t,f,f" data-frame_0="y:bottom;o:1;rX:-20deg;rY:-20deg;" data-frame_1="e:power3.out;st:2100;sp:1000;sR:2100;" data-frame_999="x:-100%;st:w;sp:1000;sR:960;" data-frame_999_mask="u:t;" style="z-index:13;"><img loading="lazy" src="images/6c52d-dollar.png" width="118" height="100" data-no-retina> 
                    </rs-layer>
                    <!--
                        -->						
                </rs-slide>
                <rs-slide data-key="rs-18" data-title="Slide" data-thumb="images/aa09a-slider-bg-3-100x50.jpg" data-duration="4520" data-anim="ei:d;eo:d;s:d;r:0;t:slideright;sl:d;">
                    <img src="images/moris-banner.png" title="Home Three" data-parallax="off" class="rev-slidebg" data-no-retina>
                    <!--
                        -->
                    <rs-layer id="slider-8-slide-18-layer-4" data-type="text" 
                    data-rsp_ch="on" data-xy="xo:108px,108px,50px,60px;y:m;yo:-119px,-119px,-127px,-121px;" 
                    data-text="s:24;l:22;fw:300;a:inherit;" data-dim="w:183px;h:32px;" data-frame_0="x:-100%;o:1;" 
                    data-frame_0_mask="u:t;" data-frame_1="st:2100;sp:1500;sR:2100;" data-frame_1_mask="u:t;" 
                    data-frame_999="y:175%;e:power2.inOut;st:w;sp:1000;sR:920;" data-frame_999_mask="u:t;" 
                    style="z-index:10;font-family:DMSans-Medium;">Instagram Marketing 
                    </rs-layer>
                    <!--
                        -->
                    <rs-layer id="slider-8-slide-18-layer-5" data-type="text" data-rsp_ch="on" 
                    data-xy="xo:108px,108px,50px,60px;y:m;yo:-33px,-33px,-72px,-73px;" 
                    data-text="w:normal;s:56,56,35,30;l:61,61,35,35;fw:700,700,900,900;a:inherit;" 
                    data-dim="w:540px,540px,368px,383px;" data-frame_0="x:-100%;o:1;" data-frame_0_mask="u:t;" 
                    data-frame_1="st:2400;sp:1500;sR:2400;" data-frame_1_mask="u:t;" 
                    data-frame_999="y:175%;e:power2.inOut;st:w;sp:1000;sR:620;" 
                    data-frame_999_mask="u:t;" style="z-index:11;font-family:DMSans-Medium;">Digital Marketing 
                    </rs-layer>
                    <!--
                        -->
                    <rs-layer id="slider-8-slide-18-layer-7" data-type="text" data-rsp_ch="on" data-xy="xo:108px,108px,46px,60px;y:m;yo:78px,78px,0,0;" data-text="w:normal;s:15;l:26;a:inherit;" data-dim="w:445px,445px,350px,350px;" data-frame_0="x:-100%;o:1;" data-frame_0_mask="u:t;" data-frame_1="st:2700;sp:1500;sR:2700;" data-frame_1_mask="u:t;" data-frame_999="y:175%;e:power2.inOut;st:w;sp:1000;sR:320;" data-frame_999_mask="u:t;" style="z-index:12;font-family:DMSans-Medium;">Share processes and data securely on a need to know basis 
                        need for reconciliation it combines. 
                    </rs-layer>
                    <!--
                        -->
                    <rs-layer id="slider-8-slide-18-layer-8" class="rev-btn" data-type="button" data-color="rgba(255,255,255,1)" data-xy="xo:108px,108px,44px,60px;y:m;yo:159px,159px,101px,100px;" data-text="w:normal;s:15;l:17;ls:1px,1px,0,0;fw:400,400,100,100;a:inherit,inherit,inherit,center;" data-dim="w:200px,200px,200px,150px;" data-rsp_bd="off" data-padding="t:21,21,21,15;r:45,45,51,30;b:21,21,21,15;l:45,45,51,30;" data-border="bor:3px,3px,3px,3px;" data-frame_0="x:-100%;o:1;" data-frame_0_mask="u:t;" data-frame_1="st:3000;sp:1500;sR:3000;" data-frame_1_mask="u:t;" data-frame_999="y:175%;e:power2.inOut;st:w;sp:1000;sR:20;" data-frame_999_mask="u:t;" data-frame_hover="bgc:#00138e;boc:#000;bor:3px,3px,3px,3px;bos:solid;oX:50;oY:50;sp:500;e:power3.in;" style="z-index:13;background-color:#ef1855;font-family:DMSans-Medium;cursor:pointer;outline:none;box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;">Get Started 
                    </rs-layer>
                    <!--
                        -->
                    <rs-layer id="slider-8-slide-18-layer-10" data-type="image" data-rsp_ch="on" data-xy="x:r;xo:38px,38px,11px,23px;yo:315px,315px,389px,370px;" data-text="l:22;a:inherit;" data-dim="w:551,551,336px,168px;h:444,444,271px,135px;" data-frame_0="x:right;o:1;" data-frame_1="st:900;sp:1500;sR:900;" data-frame_999="x:-100%;st:w;sp:1000;sR:2120;" data-frame_999_mask="u:t;" style="z-index:6;"><img loading="lazy" src="images/6e1d6-smartphone.png" width="551" height="444" data-no-retina> 
                    </rs-layer>
                    <!--
                        -->
                    <rs-layer id="slider-8-slide-18-layer-11" class="rs-pxl-1" data-type="image" data-rsp_ch="on" data-xy="xo:654px,654px,219px,219px;yo:291px,291px,181px,181px;" data-text="l:22;a:inherit;" data-dim="w:339,339,339auto,339auto;h:206,206,206px,206px;" data-vbility="t,t,f,f" data-frame_0="x:left;o:1;" data-frame_1="st:1200;sp:1500;sR:1200;" data-frame_999="x:100%;st:w;sp:1000;sR:1820;" data-frame_999_mask="u:t;" style="z-index:7;"><img loading="lazy" src="images/2f403-card.png" width="339" height="206" data-no-retina> 
                    </rs-layer>
                    <!--
                        -->
                    <rs-layer id="slider-8-slide-18-layer-12" class="rs-pxl-2" data-type="image" data-rsp_ch="on" data-xy="xo:863px;yo:400px;" data-text="l:22;a:inherit;" data-dim="w:['203','203','203','203'];h:['140','140','140','140'];" data-frame_0="y:bottom;o:1;" data-frame_1="st:1500;sp:1500;sR:1500;" data-frame_999="x:100%;st:w;sp:1000;sR:1520;" data-frame_999_mask="u:t;" style="z-index:8;"><img loading="lazy" src="images/65117-pie.png" width="203" height="140" data-no-retina> 
                    </rs-layer>
                    <!--
                        -->
                    <rs-layer id="slider-8-slide-18-layer-14" class="rs-pxl-1" data-type="image" data-rsp_ch="on" data-xy="xo:873px,873px,438px,438px;yo:231px,231px,120px,120px;" data-text="l:22;a:inherit;" data-dim="w:138px,138px,138auto,138auto;h:['171px','171px','171px','171px'];" data-vbility="t,t,f,f" data-frame_0="y:top;o:1;" data-frame_1="st:600;sp:1500;sR:600;" data-frame_999="x:-100%;st:w;sp:1000;sR:2420;" data-frame_999_mask="u:t;" style="z-index:5;"><img loading="lazy" src="images/3296e-chart.png" width="138" height="171" data-no-retina> 
                    </rs-layer>
                    <!--
                        -->
                    <rs-layer id="slider-8-slide-18-layer-15" class="rs-pxl-2" data-type="image" data-rsp_ch="on" data-xy="xo:1073px,1073px,588px,588px;yo:344px,344px,214px,214px;" data-text="l:22;a:inherit;" data-dim="w:244,244,244px,244px;h:278,278,278px,278px;" data-vbility="t,t,f,f" data-frame_0="x:right;o:1;" data-frame_1="st:1800;sp:1500;sR:1800;" data-frame_999="x:-100%;st:w;sp:1000;sR:1220;" data-frame_999_mask="u:t;" style="z-index:9;"><img loading="lazy" src="images/e1c1a-screen.png" width="244" height="278" data-no-retina> 
                    </rs-layer>
                    <!--
                        -->						
                </rs-slide>
            </rs-slides>
            </rs-module>
        </rs-module-wrap>
    </div>
    <!-- slider revolution end -->
    <!-- moris banner start -->
    <!-- <div class="main-banner">
        <div class="container">
            <div class="row align-items">
                <div class="col-lg-6 col-md-12 col-sm-6 col-xs-12">
                    <div class="banner-text aos-item" data-aos="fade-right">
                        <h2>
                        Integrated Communications —
                        informed by data, crafted
                        with passion & distributed
                        with precision
                        </h2>
                        <p>Brands need to do more than communicate, they need to connect. That requires equal parts art and science. MORIS PR is the rare combination of both.</p>
                        <a href="#" class="moris-default-btn yellow-bg">Learn More <i class="fas fa-long-arrow-alt-right" aria-hidden="true"></i></a>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12 col-sm-6 col-xs-12">
                    <div class="banner-img aos-item" >
                        <img src="images/banner-image.png" alt="banner-image" data-aos="fade-down">
                    </div>
                </div>
            </div>
        </div>
    </div> -->
    <!-- moris banner end -->
    <div class="page-section patteren-1" style="background-color:#fefaff;">
        <div class="container">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="main-title-des text-center">
                    <h2><span class="puprple-text">Moris is a Boutique</span> Public Relations Firm<br> with a <span class="red-text">Global</span> Reach</h2>
                    <span class="moris-divider">
                        <img src="images/moris-divider.png" alt="moris-divider"  data-aos="fade-right">
                    </span>
                    <p>
                        We specialize in consumer lifestyle, luxury, tech, beauty and fashion PR campaigns, using a three-pronged approach to amplify your brand: 1) traditional PR & media outreach, 2) social media & influencer marketing campaigns, and 3) experiential event PR & production, We are we are expert in Celebrity PR, Band PR, Band PR, Film Project PR, Digital PR, Work PR, Band PR Event Band PR and Social Media Growth, SEO Optimisation
                    </p>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="moris-services">
                        <div class="row">
                            <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
                                <div class="services-holder" data-aos="fade-up" data-aos-duration="1000">
                                    <div class="img-holder">
                                        <span class="img-shape">
                                            <img src="images/trp-icon.png" alt="" data-aos="zoom-out-left">
                                        </span>
                                        <span class="border-shape">
                                        </span>
                                    </div>
                                    <div class="text-holder">
                                        <h6>Traditional PR</h6>
                                        <span class="moris-divider">
                                            <img src="images/moris-divider.png" alt="moris-divider">
                                        </span>
                                        <p>
                                            Moris offers traditional PR and media outreach services to amplify your brand including pitch
                                            and press kit development, press release
                                            distribution, media training and 
                                            expert profiling.
                                        </p>
                                        <a href="#" class="read-more">Learn More <i class="fas fa-long-arrow-alt-right"></i></a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
                                <div class="services-holder" data-aos="fade-up" data-aos-duration="1000">
                                    <div class="img-holder">
                                        <span class="img-shape">
                                            <img src="images/press-media-icon.png" alt="" data-aos="zoom-out-left">
                                        </span>
                                        <span class="border-shape">
                                        </span>
                                    </div>
                                    <div class="text-holder">
                                        <h6>Press/Media</h6>
                                        <span class="moris-divider">
                                            <img src="images/moris-divider.png" alt="moris-divider">
                                        </span>
                                        <p>
                                            We handle editorial outreach using a tailored, well-researched approach designed to secure earned print and broadcast media, through
                                            relevant story pitches and desk
                                            side appointments.
                                        </p>
                                        <a href="#" class="read-more">Learn More <i class="fas fa-long-arrow-alt-right"></i></a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
                                <div class="services-holder" data-aos="fade-up" data-aos-duration="1000">
                                    <div class="img-holder">
                                        <span class="img-shape">
                                            <img src="images/digital-pr-icon.png" alt="" data-aos="zoom-out-left">
                                        </span>
                                        <span class="border-shape">
                                        </span>
                                    </div>
                                    <div class="text-holder">
                                        <h6>Digital PR</h6>
                                        <span class="moris-divider">
                                            <img src="images/moris-divider.png" alt="moris-divider">
                                        </span>
                                        <p>
                                            Using Moris's digital marketing plan you can Kick-start your business and
                                            build a brand. 
                                        </p>
                                        <a href="#" class="read-more">Learn More <i class="fas fa-long-arrow-alt-right"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="get-free-quote">
                        <img src="images/banner-patteren1.png" alt="" data-aos="fade-right" data-aos-offset="300" data-aos-easing="ease-in-sine">
                    </div>
                    <div class="free-quotes text-center">
                        <div class="btn-holder">
                            <a href="#" class="get-free">GET A FREE QUOTE <i class="fas fa-long-arrow-alt-right"></i></a>
                            <span>OR</span>
                            <a href="#" class="get-advice">GET FREE PR ADVICE <i class="fas fa-long-arrow-alt-right"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="page-section patteren-2">
        <div class="border-shape">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="main-title text-center mb-30">
                            <h2 class="white-text">Our Working Process</h2>
                            <span class="moris-divider">
                                <img src="images/moris-divider.png" alt="moris-divider"  data-aos="fade-right">
                            </span>
                        </div>
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="moris-working-flow">
                            <div class="row">
                                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                    <div class="box-holder text-center">
                                        <div class="img-holder">
                                            <div class="img-box">
                                                <img src="images/planing-icon1.png" alt="">
                                            </div>
                                        </div>
                                        <h3>Planning</h3>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                    <div class="box-holder text-center">
                                        <div class="img-holder">
                                            <div class="img-box">
                                                <img src="images/planing-icon2.png" alt="">
                                            </div>
                                        </div>
                                        <h3>Research</h3>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                    <div class="box-holder text-center">
                                        <div class="img-holder">
                                            <div class="img-box">
                                                <img src="images/planing-icon3.png" alt="">
                                            </div>
                                        </div>
                                        <h3>Optimizing</h3>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                    <div class="box-holder text-center">
                                        <div class="img-holder">
                                            <div class="img-box">
                                                <img src="images/planing-icon4.png" alt="">
                                            </div>
                                        </div>
                                        <h3>Results</h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--  -->
    <div class="page-section patteren-3" style="padding:70px 0;">
        <div class="container">
            <div class="row align-items">
                <div class="col-lg-6">
                    <div class="post-img">
                        <img src="images/post1.png" alt=""  data-aos="fade-right">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="post-text">
                        <h2 class="mb-20"  data-aos="fade-up-left"><span class="theme-color">Moris loves the Entertainment industry</span>
                        the Entertainment business challenge is never the same twice. The challenges in this industry is link same as of Real World challenges.
                        </h2>
                        <div class="moris-divider mb-30">
                            <img src="images/moris-divider.png" alt="moris-divider"  data-aos="fade-right">
                        </div>
                        <a href="#" class="moris-default-btn">GET A PROPOSAL <i class="fas fa-long-arrow-alt-right" aria-hidden="true"></i></a>
                    </div>
                </div>
            </div>
            <br>
            <br>
            <div class="row">
                <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
                    <div class="digital-services" data-aos="zoom-in-down">
                        <div class="text-holder">
                            <div class="d-flex">
                                <h3>Pitch Development</h3>
                                <div class="icon">
                                    <img src="images/icon1.png" alt="">
                                </div>
                            </div>
                            <div class="moris-divider mb-10">
                                <img src="images/moris-divider.png" alt="moris-divider"  data-aos="fade-right">
                            </div>
                            <p>We develop and determine the proper news angles for your story and craft customised and specific pitches, which targets all individual... </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
                    <div class="digital-services" data-aos="zoom-in-down">
                        <div class="text-holder">
                            <div class="d-flex">
                                <h3>Press Kit Development</h3>
                                <div class="icon">
                                    <img src="images/icon2.png" alt="">
                                </div>
                            </div>
                            <div class="moris-divider mb-10">
                                <img src="images/moris-divider.png" alt="moris-divider"  data-aos="fade-right">
                            </div>
                            <p>We craft a media kit for you, which is effective as well as informative, containing all the desired
                                information pertaining to your... </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
                    <div class="digital-services" data-aos="zoom-in-down">
                        <div class="text-holder">
                            <div class="d-flex">
                                <h3>Press Release Distribution</h3>
                                <div class="icon">
                                    <img src="images/icon3.png" alt="">
                                </div>
                            </div>
                            <div class="moris-divider mb-10">
                                <img src="images/moris-divider.png" alt="moris-divider"  data-aos="fade-right">
                            </div>
                            <p>We circulate the latest information to a wide
                                network of media outlets and journalists. Our Professional Team also aligns...</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
                    <div class="digital-services" data-aos="zoom-in-down">
                        <div class="text-holder">
                            <div class="d-flex">
                                <h3>Pitch Development</h3>
                                <div class="icon">
                                    <img src="images/icon4.png" alt="">
                                </div>
                            </div>
                            <div class="moris-divider mb-10">
                                <img src="images/moris-divider.png" alt="moris-divider"  data-aos="fade-right">
                            </div>
                            <p>We develop and determine the proper news angles for your story and craft customised and specific pitches, which targets all individual... </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
                    <div class="digital-services" data-aos="zoom-in-down">
                        <div class="text-holder">
                            <div class="d-flex">
                                <h3>Press Kit Development</h3>
                                <div class="icon">
                                    <img src="images/icon5.png" alt="">
                                </div>
                            </div>
                            <div class="moris-divider mb-10">
                                <img src="images/moris-divider.png" alt="moris-divider"  data-aos="fade-right">
                            </div>
                            <p>We craft a media kit for you, which is effective as well as informative, containing all the desired
                                information pertaining to your... </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
                    <div class="digital-services" data-aos="zoom-in-down">
                        <div class="text-holder">
                            <div class="d-flex">
                                <h3>Press Release Distribution</h3>
                                <div class="icon">
                                    <img src="images/icon6.png" alt="">
                                </div>
                            </div>
                            <div class="moris-divider mb-10">
                                <img src="images/moris-divider.png" alt="moris-divider"  data-aos="fade-right">
                            </div>
                            <p>We circulate the latest information to a wide
                                network of media outlets and journalists. Our Professional Team also aligns...</p>
                        </div>
                    </div>
                </div>
            </div>
            <br>
            <div class="row align-items">
                <div class="col-lg-7 col-md-12 col-sm-12 col-xs-12">
                    <div class="feature-post">
                        <h2>Why Your Brand Needs <br> Social Media Marketing?</h2>
                        <div class="moris-divider">
                            <img src="images/moris-divider.png" alt="moris-divider"  data-aos="fade-right">
                        </div>
                        <img src="images/social-banner.png" alt="" width="400px" data-aos="fade-up-right">
                    </div>
                </div>
                <div class="col-lg-5 col-md-12 col-sm-12 col-xs-12">
                    <div class="post-description">
                        <ul>
                            <li>
                                <div class="desc-holder">
                                    <div class="icon">
                                        <img src="images/check-icon.png" alt="">
                                    </div>
                                    <div class="text-holder">
                                        <h4>Increase Revenue</h4>
                                        <p>Social Media offers incredible advertising features to get in front of those that matter.</p>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="desc-holder">
                                    <div class="icon">
                                        <img src="images/check-icon.png" alt="">
                                    </div>
                                    <div class="text-holder">
                                        <h4>Scalability</h4>
                                        <p>Social Media Platforms combined have over three billion monthly active users to target and scale.</p>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="desc-holder">
                                    <div class="icon">
                                        <img src="images/check-icon.png" alt="">
                                    </div>
                                    <div class="text-holder">
                                        <h4>Audience Data</h4>
                                        <p>Gain valuable information about your target audience that will help you grow your brand.</p>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="desc-holder">
                                    <div class="icon">
                                        <img src="images/check-icon.png" alt="">
                                    </div>
                                    <div class="text-holder">
                                        <h4>Connect and Grow</h4>
                                        <p>Great content will build audiences who will keep coming back to engage with your brand.</p>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="desc-holder">
                                    <div class="icon">
                                        <img src="images/check-icon.png" alt="">
                                    </div>
                                    <div class="text-holder">
                                        <h4>Tracking and Analytics</h4>
                                        <p>Optimise and scale ad campaigns through advanced tracking and analytics systems.</p>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="desc-holder">
                                    <a href="#" class="moris-default-btn">GET A PROPOSAL <i class="fas fa-long-arrow-alt-right" aria-hidden="true"></i></a>
                                    <a href="#"class="moris-default-btn purple-bg">CHECK OUR PLAN <i class="fas fa-long-arrow-alt-right" aria-hidden="true"></i></a>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- call to action start -->
    <div class="page-section patteren-4">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="call-to-action">
                        <div class="row align-items">
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                <div class="text-holder">
                                    <h2>Ready to see what a Social Media Strategy can do for you?</h2>
                                    <span class="moris-divider">
                                        <img src="images/moris-divider.png" alt="moris-divider"  data-aos="fade-right">
                                    </span>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                <div class="call-to-btn text-right">
                                    <a href="#" class="moris-default-btn">SCHEDULE A CONSULTATION <i class="fas fa-long-arrow-alt-right" aria-hidden="true"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- call to action end -->
    <!-- grow your revenie start -->
    <div class="page-section patteren-6">
        <div class="container">
            <div class="row align-items">
                <div class="col-lg-6">
                    <div class="grow-revenue-text">
                        <h2>Grow your revenue with results driven SEO. Tired of not getting the results you want from your SEO?</h2>
                        <div class="moris-divider mb-20">
                            <img src="images/moris-divider.png" alt="moris-divider"  data-aos="fade-right">
                        </div>
                        <p>Our affordable SEO packages really get results, and that’s why so many businesses regularly invest in our services. Best SEO Company in India’s helps you to stay a head of your competitors. </p>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="grow-revenue-img">
                        <img src="images/seo-post.png" alt="" width="100%"  data-aos="fade-left">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- grow your revenie end -->
    <!-- revenie post start -->
    <div class="page-section move-section">
        <div class="container">
            <div class="row align-items mb-40">
                <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                    <div class="revenue-post">
                        <div class="img-holder">
                            <span class="img-shape">
                                <img src="images/monthly-seo-icon.png" alt="" data-aos="zoom-out-left" class="aos-init aos-animate">
                            </span>
                            <span class="border-shape">
                            </span>
                        </div>
                        <div class="text-holder">
                            <h4>Monthly SEO Task</h4>
                            <div class="moris-divider mb-10">
                                <img src="images/moris-divider.png" alt="moris-divider"  data-aos="fade-right">
                            </div>
                            <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                    <div class="revenue-post">
                        <div class="img-holder">
                            <span class="img-shape">
                                <img src="images/link-building-icon.png" alt="" data-aos="zoom-out-left" class="aos-init aos-animate">
                            </span>
                            <span class="border-shape">
                            </span>
                        </div>
                        <div class="text-holder">
                            <h4>Link Building</h4>
                            <div class="moris-divider mb-10">
                                <img src="images/moris-divider.png" alt="moris-divider"  data-aos="fade-right">
                            </div>
                            <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                    <div class="revenue-post">
                        <div class="img-holder">
                            <span class="img-shape">
                                <img src="images/on-page-seo-icon.png" alt="" data-aos="zoom-out-left" class="aos-init aos-animate">
                            </span>
                            <span class="border-shape">
                            </span>
                        </div>
                        <div class="text-holder">
                            <h4>On Page SEO</h4>
                            <div class="moris-divider mb-10">
                                <img src="images/moris-divider.png" alt="moris-divider"  data-aos="fade-right">
                            </div>
                            <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-12 col-sm-4 col-xs-12">
                    <div class="revenue-post-btn">
                        <a href="#" class="moris-default-btn">GET A PROPOSAL <i class="fas fa-long-arrow-alt-right" aria-hidden="true"></i></a>
                        <a href="#" class="moris-default-btn purple-bg">CHECK OUR PLAN <i class="fas fa-long-arrow-alt-right" aria-hidden="true"></i></a>
                    </div>
                </div>
            </div>
            <div class="row align-items">
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="post-2 mb-30">
                        <img src="images/post2.png" alt="" width="100%" alt="" data-aos="fade-right" data-aos-offset="300" data-aos-easing="ease-in-sine" class="aos-init aos-animate">
                    </div>
                    <div class="revenue-post-btn">
                        <a href="#" class="moris-default-btn">GET A PROPOSAL <i class="fas fa-long-arrow-alt-right" aria-hidden="true"></i></a>
                        <a href="#" class="moris-default-btn purple-bg">CHECK OUR PLAN <i class="fas fa-long-arrow-alt-right" aria-hidden="true"></i></a>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="post2-text">
                        <h2>Only pay for sales leads with every call tracked</h2>
                        <div class="moris-divider mb-20">
                            <img src="images/moris-divider.png" alt="moris-divider"  data-aos="fade-right">
                        </div>
                        <p>We create you a fully optimised lead generation website with a focus on converting users to sales leads. Our team of experts consistently track and measure the performance of your website to ensure you’re receiving all the leads you can handle.</p>
                    </div>
                    <div class="post-guide-box">
                        <ul>
                            <li>
                                <i class="far fa-check-circle"></i>
                                <h4> Risk-free lead generation</h4>
                            </li>
                            <li>
                                <i class="far fa-check-circle"></i> 
                                <h4>Never pay for a Google click again</h4>
                            </li>
                            <li>
                                <i class="far fa-check-circle"></i> 
                                <h4>Exclusive phone leads direct to you</h4>
                            </li>
                            <li>
                                <i class="far fa-check-circle"></i> 
                                <h4>Exclusive phone leads direct to you</h4>
                            </li>
                            <li>
                                <i class="far fa-check-circle"></i> 
                                <h4>Generate higher-converting sales in just seven days</h4>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- revenie post end -->
    <!-- moris priceplan section strat -->
    <div class="page-section price-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="moris-price-plan">
                        <div class="text-center">
                            <h2>Our Pricing Plans</h2>
                            <div class="moris-divider mb-20">
                                <img src="images/moris-divider.png" alt="moris-divider"  data-aos="fade-right">
                            </div>
                        </div>
                        <!-- price plan -->
                        <ul class="nav moris-tab nav-tabs" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="socialmedia" data-bs-toggle="tab" data-bs-target="#socialmedia-tab" type="button" role="tab" aria-controls="socialmedia-tab" aria-selected="true">Social Media</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link active" id="seo" data-bs-toggle="tab" data-bs-target="#seo-tab" type="button" role="tab" aria-controls="seo-tab" aria-selected="false">SEO</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="leadgenration" data-bs-toggle="tab" data-bs-target="#leadgenration-tab" type="button" role="tab" aria-controls="leadgenration-tab" aria-selected="false">Lead Genration</button>
                            </li>
                        </ul>
                        <!-- choose price plan -->
                        <div class="tab-content">
                            <div class="tab-pane fade " id="socialmedia-tab" role="tabpanel" aria-labelledby="socialmedia-tab">
                                <div class="row">
                                    <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12 border-right">
                                        <div class="price-plan-holder">
                                            <div class="img-holder">
                                                <img src="images/price-icon.png" alt="" width="100%">
                                            </div>
                                            <div class="text-holder">
                                                <p>Guranteed Leeds</p>
                                                <p>Lead Generations Strategy</p>
                                                <p>Conversion Rate</p>
                                                <p>Content Development</p>
                                                <p>Landing Page Ad Design</p>
                                                <p>Ad Content Description</p>
                                                <p>First Interaction with Lead</p>
                                                <a href="#" class="moris-default-btn view-more">view more options</a>
                                            </div>
                                            <div class="quotation text-center has-bg">
                                                <h3>Quotation</h3>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12">
                                        <div class="price-plan-holder">
                                            <div class="img-holder text-center purple-bg">
                                                <div class="icon">
                                                    <img src="images/price-icon2.png" alt="">
                                                </div>
                                                <div class="price-caption">
                                                    <h2>Starter </h2>
                                                    <p>Closure 2-Months</p>
                                                </div>
                                            </div>
                                            <div class="text-holder text-center">
                                                <p>75 Per Month</p>
                                                <p>Yes</p>
                                                <p>10-24%</p>
                                                <p>Yes</p>
                                                <p>Yes</p>
                                                <p>Yes</p>
                                                <p>No</p>
                                                <a href="#" class="moris-default-btn">GET A PROPOSAL <i class="fas fa-long-arrow-alt-right" aria-hidden="true"></i></a>
                                            </div>
                                            <div class="quotation text-center border-top">
                                                <div>
                                                    <strong>75,000</strong>
                                                    <span>Per Month</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12 price-patteren">
                                        <div class="price-plan-holder">
                                            <div class="img-holder text-center">
                                                <div class="icon">
                                                    <img src="images/price-icon3.png" alt="">
                                                </div>
                                                <div class="price-caption">
                                                    <h2>Growth</h2>
                                                    <p>Closure 2-Months</p>
                                                </div>
                                            </div>
                                            <div class="text-holder text-center">
                                                <p>180 Per Month</p>
                                                <p>Yes</p>
                                                <p>10-28%</p>
                                                <p>Yes</p>
                                                <p>Yes</p>
                                                <p>Yes</p>
                                                <p>No</p>
                                                <a href="#" class="moris-default-btn yellow-bg">GET A PROPOSAL <i class="fas fa-long-arrow-alt-right" aria-hidden="true"></i></a>
                                            </div>
                                            <div class="quotation text-center">
                                                <div>
                                                    <strong>130,000</strong>
                                                    <span>Per Month</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12">
                                        <div class="price-plan-holder">
                                            <div class="img-holder text-center purple-bg" style="border-top-right-radius:8px">
                                                <div class="icon">
                                                    <img src="images/price-icon4.png" alt="">
                                                </div>
                                                <div class="price-caption">
                                                    <h2>Enterprise</h2>
                                                    <p>Closure 3-Months</p>
                                                </div>
                                            </div>
                                            <div class="text-holder text-center">
                                                <p>350 Per Month</p>
                                                <p>Yes</p>
                                                <p>18-32%</p>
                                                <p>Yes</p>
                                                <p>Yes</p>
                                                <p>Yes</p>
                                                <p>No</p>
                                                <a href="#" class="moris-default-btn">GET A PROPOSAL <i class="fas fa-long-arrow-alt-right" aria-hidden="true"></i></a>
                                            </div>
                                            <div class="quotation text-center border-top">
                                                <div>
                                                    <strong>240,000</strong>
                                                    <span>Per Month</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade show active" id="seo-tab" role="tabpanel" aria-labelledby="seo-tab">
                                <div class="row">
                                    <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12 border-right">
                                        <div class="price-plan-holder">
                                            <div class="img-holder">
                                                <img src="images/price-icon.png" alt="" width="100%">
                                            </div>
                                            <div class="text-holder">
                                                <p>Guranteed Leeds</p>
                                                <p>Lead Generations Strategy</p>
                                                <p>Conversion Rate</p>
                                                <p>Content Development</p>
                                                <p>Landing Page Ad Design</p>
                                                <p>Ad Content Description</p>
                                                <p>First Interaction with Lead</p>
                                                <a href="#" class="moris-default-btn view-more">view more options</a>
                                            </div>
                                            <div class="quotation text-center has-bg">
                                                <h3>Quotation</h3>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12">
                                        <div class="price-plan-holder">
                                            <div class="img-holder text-center purple-bg">
                                                <div class="icon">
                                                    <img src="images/price-icon2.png" alt="">
                                                </div>
                                                <div class="price-caption">
                                                    <h2>Starter </h2>
                                                    <p>Closure 2-Months</p>
                                                </div>
                                            </div>
                                            <div class="text-holder text-center">
                                                <p>75 Per Month</p>
                                                <p>Yes</p>
                                                <p>10-24%</p>
                                                <p>Yes</p>
                                                <p>Yes</p>
                                                <p>Yes</p>
                                                <p>No</p>
                                                <a href="#" class="moris-default-btn">GET A PROPOSAL <i class="fas fa-long-arrow-alt-right" aria-hidden="true"></i></a>
                                            </div>
                                            <div class="quotation text-center border-top">
                                                <div>
                                                    <strong>75,000</strong>
                                                    <span>Per Month</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12 price-patteren">
                                        <div class="price-plan-holder">
                                            <div class="img-holder text-center">
                                                <div class="icon">
                                                    <img src="images/price-icon3.png" alt="">
                                                </div>
                                                <div class="price-caption">
                                                    <h2>Growth</h2>
                                                    <p>Closure 2-Months</p>
                                                </div>
                                            </div>
                                            <div class="text-holder text-center">
                                                <p>180 Per Month</p>
                                                <p>Yes</p>
                                                <p>10-28%</p>
                                                <p>Yes</p>
                                                <p>Yes</p>
                                                <p>Yes</p>
                                                <p>No</p>
                                                <a href="#" class="moris-default-btn yellow-bg">GET A PROPOSAL <i class="fas fa-long-arrow-alt-right" aria-hidden="true"></i></a>
                                            </div>
                                            <div class="quotation text-center">
                                                <div>
                                                    <strong>130,000</strong>
                                                    <span>Per Month</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12">
                                        <div class="price-plan-holder">
                                            <div class="img-holder text-center purple-bg" style="border-top-right-radius:8px">
                                                <div class="icon">
                                                    <img src="images/price-icon4.png" alt="">
                                                </div>
                                                <div class="price-caption">
                                                    <h2>Enterprise</h2>
                                                    <p>Closure 3-Months</p>
                                                </div>
                                            </div>
                                            <div class="text-holder text-center">
                                                <p>350 Per Month</p>
                                                <p>Yes</p>
                                                <p>18-32%</p>
                                                <p>Yes</p>
                                                <p>Yes</p>
                                                <p>Yes</p>
                                                <p>No</p>
                                                <a href="#" class="moris-default-btn">GET A PROPOSAL <i class="fas fa-long-arrow-alt-right" aria-hidden="true"></i></a>
                                            </div>
                                            <div class="quotation text-center border-top">
                                                <div>
                                                    <strong>240,000</strong>
                                                    <span>Per Month</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="leadgenration-tab" role="tabpanel" aria-labelledby="leadgenration-tab">
                                <div class="row">
                                    <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12 border-right">
                                        <div class="price-plan-holder">
                                            <div class="img-holder">
                                                <img src="images/price-icon.png" alt="" width="100%">
                                            </div>
                                            <div class="text-holder">
                                                <p>Guranteed Leeds</p>
                                                <p>Lead Generations Strategy</p>
                                                <p>Conversion Rate</p>
                                                <p>Content Development</p>
                                                <p>Landing Page Ad Design</p>
                                                <p>Ad Content Description</p>
                                                <p>First Interaction with Lead</p>
                                                <a href="#" class="moris-default-btn view-more">view more options</a>
                                            </div>
                                            <div class="quotation text-center has-bg">
                                                <h3>Quotation</h3>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12">
                                        <div class="price-plan-holder">
                                            <div class="img-holder text-center purple-bg">
                                                <div class="icon">
                                                    <img src="images/price-icon2.png" alt="">
                                                </div>
                                                <div class="price-caption">
                                                    <h2>Starter </h2>
                                                    <p>Closure 2-Months</p>
                                                </div>
                                            </div>
                                            <div class="text-holder text-center">
                                                <p>75 Per Month</p>
                                                <p>Yes</p>
                                                <p>10-24%</p>
                                                <p>Yes</p>
                                                <p>Yes</p>
                                                <p>Yes</p>
                                                <p>No</p>
                                                <a href="#" class="moris-default-btn">GET A PROPOSAL <i class="fas fa-long-arrow-alt-right" aria-hidden="true"></i></a>
                                            </div>
                                            <div class="quotation text-center border-top">
                                                <div>
                                                    <strong>75,000</strong>
                                                    <span>Per Month</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12 price-patteren">
                                        <div class="price-plan-holder">
                                            <div class="img-holder text-center">
                                                <div class="icon">
                                                    <img src="images/price-icon3.png" alt="">
                                                </div>
                                                <div class="price-caption">
                                                    <h2>Growth</h2>
                                                    <p>Closure 2-Months</p>
                                                </div>
                                            </div>
                                            <div class="text-holder text-center">
                                                <p>180 Per Month</p>
                                                <p>Yes</p>
                                                <p>10-28%</p>
                                                <p>Yes</p>
                                                <p>Yes</p>
                                                <p>Yes</p>
                                                <p>No</p>
                                                <a href="#" class="moris-default-btn yellow-bg">GET A PROPOSAL <i class="fas fa-long-arrow-alt-right" aria-hidden="true"></i></a>
                                            </div>
                                            <div class="quotation text-center">
                                                <div>
                                                    <strong>130,000</strong>
                                                    <span>Per Month</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12">
                                        <div class="price-plan-holder">
                                            <div class="img-holder text-center purple-bg" style="border-top-right-radius:8px">
                                                <div class="icon">
                                                    <img src="images/price-icon4.png" alt="">
                                                </div>
                                                <div class="price-caption">
                                                    <h2>Enterprise</h2>
                                                    <p>Closure 3-Months</p>
                                                </div>
                                            </div>
                                            <div class="text-holder text-center">
                                                <p>350 Per Month</p>
                                                <p>Yes</p>
                                                <p>18-32%</p>
                                                <p>Yes</p>
                                                <p>Yes</p>
                                                <p>Yes</p>
                                                <p>No</p>
                                                <a href="#" class="moris-default-btn">GET A PROPOSAL <i class="fas fa-long-arrow-alt-right" aria-hidden="true"></i></a>
                                            </div>
                                            <div class="quotation text-center border-top">
                                                <div>
                                                    <strong>240,000</strong>
                                                    <span>Per Month</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- moris priceplan section end -->
    <!-- demo section start -->
    <div class="page-section patteren-8">
        <div class="container">
            <div class="row">
                <div class="row align-items">
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <div class="text-holder">
                            <h2>Schedule a Demo <br> Understand your Business</h2>
                            <div class="moris-divider mb-20">
                                <img src="images/moris-divider.png" alt="moris-divider"  data-aos="fade-right">
                            </div>
                            <a href="#" class="moris-default-btn">FREE CONSULTATION <i class="fas fa-long-arrow-alt-right" aria-hidden="true"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <div class="video-demo-post">
                            <img src="images/demo-video.png" alt="" width="100%" data-aos="fade-left">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Back to top button -->
    <a id="button"></a>
<?php include 'footer.php';?>
