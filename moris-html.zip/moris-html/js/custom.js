function openNav() {
    document.getElementById("morisSidenav").style.width = "100%";
    }

    function closeNav() {
    document.getElementById("morisSidenav").style.width = "0";
    }
    // for moris side nav 
    // for moris search bar
    function openSearch() {
        document.getElementById("searchOverlay").style.display = "block";
      }
      
      function closeSearch() {
        document.getElementById("searchOverlay").style.display = "none";
      }
      // for mobile view
      function openMobile() {
        document.getElementById("mobileview-menu").style.width = "98%";
        }

        function closeMobile() {
        document.getElementById("mobileview-menu").style.width = "0";
        }
        // rev slider start

        // for mega menu 

                  






        
           
        